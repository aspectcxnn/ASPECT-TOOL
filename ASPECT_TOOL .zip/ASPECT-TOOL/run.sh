#!/usr/bin/env bash
# ASPECT OSINT Tool Launcher for Arch Linux KDE Plasma

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR" || exit 1

VENV_DIR="$SCRIPT_DIR/venv"

if [ ! -d "$VENV_DIR" ]; then
    echo -e "\e[1;35m[ASPECT]\e[0m Sanal ortam hazırlanıyor..."
    python3 -m venv "$VENV_DIR"
    "$VENV_DIR/bin/pip" install -r "$SCRIPT_DIR/requirements.txt"
fi

# Run ASPECT
"$VENV_DIR/bin/python3" "$SCRIPT_DIR/aspect.py"
