"""
Module 2: Email OSINT
- Email domain information
- DNS records for domain (MX, SPF, DMARC)
- Gravatar open source profile and avatar detection (MD5 hash)
- Open source search results and dorks mentioning the email
"""

import hashlib
import re
import urllib.parse
import webbrowser
import requests
import dns.resolver

from utils.colors import (
    c, status_msg, section_header, key_val,
    NEON_PURPLE, NEON_PINK, CYAN, GREEN, YELLOW, RED, WHITE, GRAY, RESET, BOLD
)

def run_email_osint():
    section_header("2. EMAIL OSINT")
    email = input(f"{BOLD}{NEON_PURPLE}[>] Email to analyze:{RESET} ").strip()
    
    if not re.match(r"[^@]+@[^@]+\.[^@]+", email):
        status_msg("!", "Invalid email address format!", RED)
        input(f"\n{GRAY}Press Enter to continue...{RESET}")
        return

    username, domain = email.split("@", 1)
    
    print()
    status_msg("i", f"Target: {email}", CYAN)
    key_val("User / Local Part", username)
    key_val("Domain", domain)

    # 1. DNS & Mail Records
    print(f"\n{BOLD}{NEON_PURPLE}[1] Domain DNS & Email Security Records:{RESET}")
    # MX
    try:
        mx_answers = dns.resolver.resolve(domain, 'MX', lifetime=5)
        for rdata in mx_answers:
            print(f"  {GREEN}• MX Server:{RESET} {WHITE}{rdata.exchange}{RESET} (Priority: {rdata.preference})")
    except Exception as e:
        print(f"  {YELLOW}• MX Record not found or could not be resolved.{RESET}")

    # SPF / TXT
    try:
        txt_answers = dns.resolver.resolve(domain, 'TXT', lifetime=5)
        spf_found = False
        for rdata in txt_answers:
            txt_str = "".join([s.decode('utf-8', errors='ignore') if isinstance(s, bytes) else str(s) for s in rdata.strings])
            if "v=spf1" in txt_str:
                spf_found = True
                print(f"  {GREEN}• SPF Record:{RESET} {WHITE}{txt_str}{RESET}")
        if not spf_found:
            print(f"  {YELLOW}• SPF Record not found.{RESET}")
    except Exception:
        print(f"  {YELLOW}• TXT/SPF Record could not be resolved.{RESET}")

    # DMARC
    try:
        dmarc_answers = dns.resolver.resolve(f"_dmarc.{domain}", 'TXT', lifetime=5)
        for rdata in dmarc_answers:
            txt_str = "".join([s.decode('utf-8', errors='ignore') if isinstance(s, bytes) else str(s) for s in rdata.strings])
            print(f"  {GREEN}• DMARC Record:{RESET} {WHITE}{txt_str}{RESET}")
    except Exception:
        print(f"  {YELLOW}• DMARC Record not found.{RESET}")

    # 2. Gravatar Check
    print(f"\n{BOLD}{NEON_PURPLE}[2] Gravatar Public Profile Scan:{RESET}")
    email_clean = email.strip().lower()
    email_hash = hashlib.md5(email_clean.encode('utf-8')).hexdigest()
    gravatar_avatar_url = f"https://www.gravatar.com/avatar/{email_hash}?d=404"
    gravatar_json_url = f"https://en.gravatar.com/{email_hash}.json"

    try:
        avatar_resp = requests.get(gravatar_avatar_url, timeout=5)
        if avatar_resp.status_code == 200:
            print(f"  {GREEN}[✓] Gravatar profile found!{RESET}")
            print(f"  {NEON_PINK}• Avatar URL:{RESET} {WHITE}{gravatar_avatar_url}{RESET}")
            
            # Try fetching JSON details
            try:
                profile_resp = requests.get(gravatar_json_url, headers={"User-Agent": "Mozilla/5.0"}, timeout=5)
                if profile_resp.status_code == 200:
                    data = profile_resp.json()
                    entry = data.get("entry", [{}])[0]
                    if entry.get("displayName"):
                        key_val("Display Name", entry.get("displayName"), indent=4)
                    if entry.get("preferredUsername"):
                        key_val("Username", entry.get("preferredUsername"), indent=4)
                    if entry.get("currentLocation"):
                        key_val("Location", entry.get("currentLocation"), indent=4)
                    if entry.get("aboutMe"):
                        key_val("About Me", entry.get("aboutMe"), indent=4)
                    if entry.get("profileUrl"):
                        key_val("Profile URL", entry.get("profileUrl"), indent=4)
            except Exception:
                pass
        else:
            print(f"  {GRAY}[-] No public Gravatar avatar/profile found for this email.{RESET}")
    except Exception as e:
        print(f"  {RED}Gravatar lookup error: {e}{RESET}")

    # 3. Open Source Web Searches (Google Dorks)
    print(f"\n{BOLD}{NEON_PURPLE}[3] Open Source Web Search Tips:{RESET}")
    dorks = [
        f'"{email}"',
        f'"{email}" site:pastebin.com',
        f'"{email}" filetype:pdf OR filetype:txt OR filetype:doc',
        f'"{email}" site:github.com',
        f'"{email}" site:linkedin.com',
    ]

    for dork in dorks:
        search_url = f"https://www.google.com/search?q={urllib.parse.quote(dork)}"
        print(f"  {CYAN}• Dork:{RESET} {WHITE}{dork}{RESET}")
        print(f"    {GRAY}Link: {search_url}{RESET}")

    open_in_browser = input(f"\n{BOLD}{NEON_PINK}[?] Open search links in browser? (y/n):{RESET} ").strip().lower()
    if open_in_browser in ['y', 'yes', 'e']:
        webbrowser.open_new_tab(f"https://www.google.com/search?q={urllib.parse.quote(f'\"{email}\"')}")
        print(f"{GREEN}[✓] Search opened in browser.{RESET}")

    input(f"\n{NEON_PURPLE}[⏎] Press Enter to return to main menu...{RESET}")
