"""
Module: Discord Developer & Utility Suite (Page 4 - Discord Checker)
Comprehensive, secure, public API compliant OSINT & Developer Utilities.
Technologies: asyncio, aiohttp, datetime, re, json
"""

import os
import re
import sys
import time
import json
import asyncio
import datetime
from typing import List, Dict, Any, Optional
import aiohttp

from utils.colors import (
    c, status_msg, section_header, key_val,
    NEON_PURPLE, DEEP_PURPLE, DARK_PURPLE, NEON_PINK, HOT_PINK,
    CYAN, GREEN, YELLOW, RED, WHITE, GRAY, DARK_GRAY, RESET, BOLD
)

DISCORD_EPOCH = 1420070400000  # Jan 1, 2015 UTC

def get_desktop_dir() -> str:
    """Returns the Desktop directory path."""
    desktop_dir = "/home/aspect/Masaüstü"
    if not os.path.exists(desktop_dir):
        desktop_dir = os.path.expanduser("~/Desktop")
    if not os.path.exists(desktop_dir):
        os.makedirs(desktop_dir, exist_ok=True)
    return desktop_dir

def save_txt_report(title_prefix: str, content: str) -> None:
    """Saves the report as a TXT file on Desktop based on user choice."""
    print(f"\n{DARK_PURPLE}{'━' * 60}{RESET}")
    print(f"  {BOLD}{NEON_PURPLE}<<0>>{RESET} {WHITE}[Save TXT Report to Desktop]{RESET}")
    print(f"  {BOLD}{NEON_PURPLE}<<1>>{RESET} {WHITE}[Exit and Return to Main Menu]{RESET}")
    print(f"{DARK_PURPLE}{'━' * 60}{RESET}")

    while True:
        action = input(f"\n{BOLD}{NEON_PINK}[>] Choice (0 / 1):{RESET} ").strip()
        if action == "0":
            desktop_dir = get_desktop_dir()
            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"ASPECT_DISCORD_{title_prefix}_{timestamp}.txt"
            filepath = os.path.join(desktop_dir, filename)

            try:
                with open(filepath, "w", encoding="utf-8") as f:
                    f.write(content)
                print(f"\n{GREEN}{BOLD}[✓] Report successfully saved to Desktop!{RESET}")
                print(f"  {NEON_PINK}File Path:{RESET} {WHITE}{filepath}{RESET}")
            except Exception as e:
                print(f"\n{RED}[!] Error saving file: {e}{RESET}")

            input(f"\n{NEON_PURPLE}[⏎] Press Enter to return to menu...{RESET}")
            break
        elif action == "1":
            print(f"{CYAN}Returning to menu...{RESET}")
            break
        else:
            print(f"{RED}Invalid choice! Please enter 0 or 1.{RESET}")

def decode_snowflake(snowflake_id: int) -> Dict[str, Any]:
    """Decodes Discord Snowflake ID to calculate creation date and age."""
    try:
        timestamp_ms = (snowflake_id >> 22) + DISCORD_EPOCH
        dt_utc = datetime.datetime.fromtimestamp(timestamp_ms / 1000.0, tz=datetime.timezone.utc)
        worker_id = (snowflake_id & 0x3E0000) >> 17
        process_id = (snowflake_id & 0x1F000) >> 12
        increment = snowflake_id & 0xFFF

        now_utc = datetime.datetime.now(datetime.timezone.utc)
        diff = now_utc - dt_utc

        days = diff.days
        years = days // 365
        rem_days = days % 365
        hours = diff.seconds // 3600
        minutes = (diff.seconds % 3600) // 60

        return {
            "valid": True,
            "id": snowflake_id,
            "timestamp_ms": timestamp_ms,
            "dt_utc": dt_utc.strftime("%Y-%m-%d %H:%M:%S UTC"),
            "dt_local": dt_utc.astimezone().strftime("%Y-%m-%d %H:%M:%S %Z"),
            "unix_timestamp": int(timestamp_ms / 1000),
            "age_str": f"{years} years, {rem_days} days, {hours} hours, {minutes} minutes",
            "worker_id": worker_id,
            "process_id": process_id,
            "increment": increment
        }
    except Exception as e:
        return {"valid": False, "error": str(e)}

# -----------------------------------------------------------------------------
# 1. Invite Link Analyzer
# -----------------------------------------------------------------------------
async def async_fetch_invite(invite_code: str) -> Dict[str, Any]:
    url = f"https://discord.com/api/v10/invites/{invite_code}?with_counts=true&with_expiration=true"
    headers = {"User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"}
    conn = aiohttp.TCPConnector(ssl=False)
    async with aiohttp.ClientSession(connector=conn) as session:
        try:
            async with session.get(url, headers=headers, timeout=aiohttp.ClientTimeout(total=8)) as resp:
                text = await resp.text()
                if "erisime_engellenmis" in text or (resp.status == 200 and "<html" in text.lower()):
                    return {"success": False, "error": "Cannot connect to Discord API (ISP/DNS Restriction or Cloudflare Challenge)."}
                if resp.status == 200:
                    try:
                        data = json.loads(text)
                        return {"success": True, "data": data}
                    except json.JSONDecodeError:
                        return {"success": False, "error": "Invalid JSON response received."}
                elif resp.status == 404:
                    return {"success": False, "error": "Invalid or expired Discord invite link/code."}
                else:
                    return {"success": False, "error": f"Discord API Response Error (HTTP {resp.status})"}
        except Exception as e:
            return {"success": False, "error": f"Connection error: {str(e)}"}

def run_invite_analyzer():
    section_header("DISCORD SUITE: INVITE LINK ANALYZER")
    raw_input = input(f"{BOLD}{NEON_PURPLE}[>] Discord Invite Code or URL (e.g. discord.gg/python):{RESET} ").strip()
    if not raw_input:
        status_msg("!", "Invite code cannot be empty.", RED)
        input(f"\n{GRAY}Press Enter to continue...{RESET}")
        return

    match = re.search(r'(?:discord\.gg|discord\.com/invite)/([a-zA-Z0-9-]+)', raw_input)
    invite_code = match.group(1) if match else raw_input.split("/")[-1]

    status_msg("*", f"Querying invite code '{invite_code}' via Discord REST API...", CYAN)
    res = asyncio.run(async_fetch_invite(invite_code))

    if not res["success"]:
        status_msg("!", res["error"], RED)
        input(f"\n{GRAY}Press Enter to continue...{RESET}")
        return

    d = res["data"]
    guild = d.get("guild", {})
    channel = d.get("channel", {})
    inviter = d.get("inviter", {})

    guild_id = guild.get("id", "Unknown")
    guild_name = guild.get("name", "Unknown")
    description = guild.get("description") or "No description provided."
    verification_level = guild.get("verification_level", "Unspecified")
    member_count = d.get("approximate_member_count", "Unknown")
    presence_count = d.get("approximate_presence_count", "Unknown")
    features = guild.get("features", [])

    icon_hash = guild.get("icon")
    banner_hash = guild.get("banner")
    splash_hash = guild.get("splash")

    icon_url = f"https://cdn.discordapp.com/icons/{guild_id}/{icon_hash}.png?size=1024" if icon_hash else "Not Available"
    banner_url = f"https://cdn.discordapp.com/banners/{guild_id}/{banner_hash}.png?size=1024" if banner_hash else "Not Available"
    splash_url = f"https://cdn.discordapp.com/splashes/{guild_id}/{splash_hash}.png?size=1024" if splash_hash else "Not Available"

    guild_sf = decode_snowflake(int(guild_id)) if guild_id.isdigit() else {}

    print(f"\n{BOLD}{NEON_PURPLE}[◈] SERVER DETAILS:{RESET}")
    key_val("Server Name", guild_name)
    key_val("Server ID", guild_id)
    if guild_sf.get("valid"):
        key_val("Creation Date", guild_sf["dt_utc"])
        key_val("Server Age", guild_sf["age_str"])
    key_val("Description", description)
    key_val("Total Members", f"{member_count:,}" if isinstance(member_count, int) else str(member_count))
    key_val("Online Members", f"{presence_count:,}" if isinstance(presence_count, int) else str(presence_count))
    key_val("Verification Level", f"Level {verification_level}")

    print(f"\n{BOLD}{NEON_PURPLE}[◈] INVITE & CHANNEL DETAILS:{RESET}")
    key_val("Invite Code", invite_code)
    key_val("Channel Name", channel.get("name", "Unknown"))
    key_val("Channel ID", channel.get("id", "Unknown"))
    if inviter:
        inviter_tag = f"{inviter.get('username')} (ID: {inviter.get('id')})"
        key_val("Inviter User", inviter_tag)

    if features:
        print(f"\n{BOLD}{NEON_PURPLE}[◈] SERVER FEATURES / FLAGS ({len(features)}):{RESET}")
        print(f"  {CYAN}• {', '.join(features)}{RESET}")

    print(f"\n{BOLD}{NEON_PURPLE}[◈] MEDIA & ASSET URLS:{RESET}")
    key_val("Icon URL", icon_url)
    key_val("Banner URL", banner_url)
    key_val("Splash URL", splash_url)

    report_lines = [
        "==================================================",
        "ASPECT OSINT SUITE - DISCORD INVITE LINK ANALYZER",
        "==================================================",
        f"Invite Code    : {invite_code}",
        f"Server Name    : {guild_name}",
        f"Server ID      : {guild_id}",
        f"Creation Date  : {guild_sf.get('dt_utc', 'N/A')}",
        f"Server Age     : {guild_sf.get('age_str', 'N/A')}",
        f"Description    : {description}",
        f"Total Members  : {member_count}",
        f"Online Members : {presence_count}",
        f"Verification L : Level {verification_level}",
        f"Channel Name   : {channel.get('name')}",
        f"Channel ID     : {channel.get('id')}",
        f"Invited By     : {inviter.get('username') if inviter else 'Unknown'}",
        f"Icon URL       : {icon_url}",
        f"Banner URL     : {banner_url}",
        f"Splash URL     : {splash_url}",
        f"Features       : {', '.join(features)}",
        "=================================================="
    ]

    save_txt_report(f"INVITE_{invite_code}", "\n".join(report_lines))

# -----------------------------------------------------------------------------
# 2. Webhook Test & Sender
# -----------------------------------------------------------------------------
async def async_webhook_action(webhook_url: str, method: str = "GET", payload: dict = None) -> Dict[str, Any]:
    headers = {
        "Content-Type": "application/json",
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    }
    conn = aiohttp.TCPConnector(ssl=False)
    async with aiohttp.ClientSession(connector=conn) as session:
        try:
            if method == "GET":
                async with session.get(webhook_url, headers=headers, timeout=aiohttp.ClientTimeout(total=8)) as resp:
                    text = await resp.text()
                    if "erisime_engellenmis" in text or "<html" in text.lower():
                        return {"success": False, "error": "Cannot connect to Discord Webhook API (ISP/DNS Restriction)."}
                    if resp.status == 200:
                        try:
                            return {"success": True, "data": json.loads(text)}
                        except json.JSONDecodeError:
                            return {"success": False, "error": "Invalid JSON response received."}
                    else:
                        return {"success": False, "error": f"Webhook query failed (HTTP {resp.status})"}
            elif method == "POST":
                async with session.post(webhook_url, json=payload, headers=headers, timeout=aiohttp.ClientTimeout(total=10)) as resp:
                    if resp.status in [200, 204]:
                        return {"success": True, "status": resp.status}
                    else:
                        text = await resp.text()
                        return {"success": False, "error": f"Delivery failed (HTTP {resp.status}): {text[:200]}"}
        except Exception as e:
            return {"success": False, "error": f"Connection error: {str(e)}"}

def run_webhook_sender():
    section_header("DISCORD SUITE: WEBHOOK TEST & SENDER")
    webhook_url = input(f"{BOLD}{NEON_PURPLE}[>] Enter Discord Webhook URL:{RESET} ").strip()

    webhook_regex = r'https://(?:ptb\.|canary\.)?discord(?:app)?\.com/api/webhooks/(\d+)/([A-Za-z0-9_-]+)'
    match = re.match(webhook_regex, webhook_url)
    if not match:
        status_msg("!", "Invalid Discord Webhook URL format!", RED)
        input(f"\n{GRAY}Press Enter to continue...{RESET}")
        return

    status_msg("*", "Fetching webhook metadata from Discord...", CYAN)
    info_res = asyncio.run(async_webhook_action(webhook_url, "GET"))

    if not info_res["success"]:
        status_msg("!", info_res["error"], RED)
        input(f"\n{GRAY}Press Enter to continue...{RESET}")
        return

    wh = info_res["data"]
    wh_id = wh.get("id")
    wh_name = wh.get("name")
    wh_channel = wh.get("channel_id")
    wh_guild = wh.get("guild_id")
    wh_avatar = wh.get("avatar")

    print(f"\n{BOLD}{NEON_PURPLE}[◈] WEBHOOK METADATA DETAILS:{RESET}")
    key_val("Webhook Name", str(wh_name))
    key_val("Webhook ID", str(wh_id))
    key_val("Channel ID", str(wh_channel))
    key_val("Server ID", str(wh_guild))
    if wh_id and str(wh_id).isdigit():
        sf = decode_snowflake(int(wh_id))
        if sf.get("valid"):
            key_val("Creation Date", sf["dt_utc"])

    print(f"\n{DARK_PURPLE}{'━' * 60}{RESET}")
    print(f"  {BOLD}{NEON_PURPLE}<<1>>{RESET} {WHITE}[Send Simple Text Message]{RESET}")
    print(f"  {BOLD}{NEON_PURPLE}<<2>>{RESET} {WHITE}[Send Rich Embed Message]{RESET}")
    print(f"  {BOLD}{NEON_PURPLE}<<0>>{RESET} {GRAY}[Cancel and Return]{RESET}")
    print(f"{DARK_PURPLE}{'━' * 60}{RESET}")

    choice = input(f"\n{BOLD}{NEON_PINK}[>] Action Choice (1 / 2 / 0):{RESET} ").strip()

    if choice == "1":
        content = input(f"{BOLD}{WHITE}Enter Message Text:{RESET} ").strip()
        custom_name = input(f"{BOLD}{WHITE}Custom Sender Name (Optional, press Enter to skip):{RESET} ").strip()
        custom_avatar = input(f"{BOLD}{WHITE}Custom Avatar URL (Optional, press Enter to skip):{RESET} ").strip()

        if not content:
            status_msg("!", "Message content cannot be empty!", RED)
            input(f"\n{GRAY}Press Enter to continue...{RESET}")
            return

        payload = {"content": content}
        if custom_name:
            payload["username"] = custom_name
        if custom_avatar:
            payload["avatar_url"] = custom_avatar

        status_msg("*", "Delivering message via Webhook...", CYAN)
        send_res = asyncio.run(async_webhook_action(webhook_url, "POST", payload))
        if send_res["success"]:
            status_msg("+", "Message successfully delivered to Webhook channel! (HTTP 204)", GREEN)
        else:
            status_msg("!", send_res["error"], RED)

    elif choice == "2":
        embed_title = input(f"{BOLD}{WHITE}Embed Title:{RESET} ").strip()
        embed_desc = input(f"{BOLD}{WHITE}Embed Description:{RESET} ").strip()
        hex_color = input(f"{BOLD}{WHITE}Color (Hex e.g. #c084fc, press Enter to skip):{RESET} ").strip().lstrip("#")
        author_name = input(f"{BOLD}{WHITE}Author Name (Optional):{RESET} ").strip()
        footer_text = input(f"{BOLD}{WHITE}Footer Text (Optional):{RESET} ").strip()
        image_url = input(f"{BOLD}{WHITE}Image URL (Optional):{RESET} ").strip()

        color_int = 0xc084fc
        if hex_color:
            try:
                color_int = int(hex_color, 16)
            except ValueError:
                pass

        embed = {
            "title": embed_title or "ASPECT Suite",
            "description": embed_desc or "Rich embed message delivered from ASPECT terminal.",
            "color": color_int,
            "timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat()
        }
        if author_name:
            embed["author"] = {"name": author_name}
        if footer_text:
            embed["footer"] = {"text": footer_text}
        if image_url:
            embed["image"] = {"url": image_url}

        payload = {"embeds": [embed]}

        status_msg("*", "Delivering Rich Embed message via Webhook...", CYAN)
        send_res = asyncio.run(async_webhook_action(webhook_url, "POST", payload))
        if send_res["success"]:
            status_msg("+", "Rich Embed message successfully sent to channel!", GREEN)
        else:
            status_msg("!", send_res["error"], RED)

    report_lines = [
        "==================================================",
        "ASPECT OSINT SUITE - DISCORD WEBHOOK LOG",
        "==================================================",
        f"Webhook Name  : {wh_name}",
        f"Webhook ID    : {wh_id}",
        f"Channel ID    : {wh_channel}",
        f"Guild ID      : {wh_guild}",
        f"Target URL    : {webhook_url}",
        f"Timestamp     : {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        "=================================================="
    ]
    save_txt_report(f"WEBHOOK_{wh_id}", "\n".join(report_lines))

# -----------------------------------------------------------------------------
# 3. Snowflake ID Decrypter
# -----------------------------------------------------------------------------
def run_snowflake_decrypter():
    section_header("DISCORD SUITE: SNOWFLAKE ID DECRYPTER")
    raw_input = input(f"{BOLD}{NEON_PURPLE}[>] Discord Snowflake ID(s) (Separated by space or comma):{RESET} ").strip()
    if not raw_input:
        status_msg("!", "ID input cannot be empty.", RED)
        input(f"\n{GRAY}Press Enter to continue...{RESET}")
        return

    tokens = re.findall(r'\b\d{17,20}\b', raw_input)
    if not tokens:
        status_msg("!", "No valid 17-20 digit Discord Snowflake ID found.", RED)
        input(f"\n{GRAY}Press Enter to continue...{RESET}")
        return

    report_lines = [
        "==================================================",
        "ASPECT OSINT SUITE - SNOWFLAKE DECRYPTION REPORT",
        "=================================================="
    ]

    for idx, token_str in enumerate(tokens, 1):
        sf_id = int(token_str)
        res = decode_snowflake(sf_id)
        print(f"\n{BOLD}{NEON_PURPLE}[# {idx}] SNOWFLAKE ANALYSIS: {WHITE}{sf_id}{RESET}")
        if not res["valid"]:
            print(f"  {RED}Decryption Error: {res['error']}{RESET}")
            continue

        key_val("Snowflake ID", str(res["id"]))
        key_val("Creation (UTC)", res["dt_utc"])
        key_val("Creation (Local Time)", res["dt_local"])
        key_val("Unix Timestamp", str(res["unix_timestamp"]))
        key_val("Account / Item Age", res["age_str"])
        key_val("Worker ID", str(res["worker_id"]))
        key_val("Process ID", str(res["process_id"]))
        key_val("Increment Counter", str(res["increment"]))

        report_lines.extend([
            f"\n--- ID #{idx}: {sf_id} ---",
            f"Creation UTC     : {res['dt_utc']}",
            f"Local Time       : {res['dt_local']}",
            f"Unix Timestamp   : {res['unix_timestamp']}",
            f"Entity Age       : {res['age_str']}",
            f"Worker ID        : {res['worker_id']}",
            f"Process ID       : {res['process_id']}",
            f"Increment        : {res['increment']}"
        ])

    report_lines.append("\n==================================================")
    save_txt_report("SNOWFLAKE_DECRYPT", "\n".join(report_lines))

# -----------------------------------------------------------------------------
# 4. Bot & Application Inspector
# -----------------------------------------------------------------------------
async def async_inspect_bot_app(client_id: str) -> Dict[str, Any]:
    url = f"https://discord.com/api/v10/applications/{client_id}/rpc"
    headers = {"User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"}
    conn = aiohttp.TCPConnector(ssl=False)
    async with aiohttp.ClientSession(connector=conn) as session:
        try:
            async with session.get(url, headers=headers, timeout=aiohttp.ClientTimeout(total=8)) as resp:
                text = await resp.text()
                if "erisime_engellenmis" in text or "<html" in text.lower():
                    return {"success": False, "error": "Cannot access Discord RPC API (ISP/DNS Restriction)."}
                if resp.status == 200:
                    try:
                        return {"success": True, "data": json.loads(text)}
                    except json.JSONDecodeError:
                        return {"success": False, "error": "Invalid JSON response received."}
                else:
                    return {"success": False, "error": f"Public RPC application details restricted (HTTP {resp.status})"}
        except Exception as e:
            return {"success": False, "error": f"Connection error: {str(e)}"}

def run_bot_inspector():
    section_header("DISCORD SUITE: BOT & APPLICATION INSPECTOR")
    client_id = input(f"{BOLD}{NEON_PURPLE}[>] Enter Bot Client / Application ID:{RESET} ").strip()
    if not client_id.isdigit() or len(client_id) < 17:
        status_msg("!", "Please enter a valid numeric Bot Client ID.", RED)
        input(f"\n{GRAY}Press Enter to continue...{RESET}")
        return

    sf = decode_snowflake(int(client_id))

    status_msg("*", f"Analyzing Bot Application ID '{client_id}'...", CYAN)
    rpc_res = asyncio.run(async_inspect_bot_app(client_id))

    app_name = "Unknown / Hidden"
    app_desc = "No public details provided."
    if rpc_res["success"]:
        data = rpc_res["data"]
        app_name = data.get("name", app_name)
        app_desc = data.get("description", app_desc)

    link_no_perm = f"https://discord.com/api/v10/oauth2/authorize?client_id={client_id}&scope=bot%20applications.commands&permissions=0"
    link_admin = f"https://discord.com/api/v10/oauth2/authorize?client_id={client_id}&scope=bot%20applications.commands&permissions=8"
    link_mod = f"https://discord.com/api/v10/oauth2/authorize?client_id={client_id}&scope=bot%20applications.commands&permissions=8589934591"
    link_standard = f"https://discord.com/api/v10/oauth2/authorize?client_id={client_id}&scope=bot%20applications.commands&permissions=274878024704"

    print(f"\n{BOLD}{NEON_PURPLE}[◈] BOT APPLICATION ANALYSIS:{RESET}")
    key_val("Bot / App ID", client_id)
    key_val("Application Name", app_name)
    if sf.get("valid"):
        key_val("Creation Date", sf["dt_utc"])
        key_val("Application Age", sf["age_str"])
    key_val("Description", app_desc)

    print(f"\n{BOLD}{NEON_PURPLE}[◈] OAUTH2 INVITE LINKS:{RESET}")
    key_val("Default (0 Perms)", link_no_perm)
    key_val("Administrator (Admin - 8)", link_admin)
    key_val("Moderation Perms", link_mod)
    key_val("Standard Chat & Voice", link_standard)

    report_lines = [
        "==================================================",
        "ASPECT OSINT SUITE - BOT & APP INSPECTION REPORT",
        "==================================================",
        f"Client ID     : {client_id}",
        f"App Name      : {app_name}",
        f"Creation Date : {sf.get('dt_utc', 'N/A')}",
        f"App Age       : {sf.get('age_str', 'N/A')}",
        f"Description   : {app_desc}",
        "--- OAuth2 Invite Links ---",
        f"No Perms      : {link_no_perm}",
        f"Admin Perms   : {link_admin}",
        f"Mod Perms     : {link_mod}",
        f"Standard      : {link_standard}",
        "=================================================="
    ]
    save_txt_report(f"BOT_INSPECT_{client_id}", "\n".join(report_lines))

# -----------------------------------------------------------------------------
# 5. Markdown & Timestamp Generator
# -----------------------------------------------------------------------------
def run_markdown_generator():
    section_header("DISCORD SUITE: MARKDOWN & TIMESTAMP GENERATOR")
    print(f"{DARK_PURPLE}{'━' * 60}{RESET}")
    print(f"  {BOLD}{NEON_PURPLE}<<1>>{RESET} {WHITE}[Generate Dynamic Timestamp Code (Relative Timestamp)]{RESET}")
    print(f"  {BOLD}{NEON_PURPLE}<<2>>{RESET} {WHITE}[Discord Text Formatting Cheat Sheet]{RESET}")
    print(f"{DARK_PURPLE}{'━' * 60}{RESET}")

    choice = input(f"\n{BOLD}{NEON_PINK}[>] Choice (1 / 2):{RESET} ").strip()

    if choice == "1":
        print(f"\n{CYAN}Select Timestamp Target:{RESET}")
        print(f"  [1] Current Time (Now)")
        print(f"  [2] Enter Custom Date & Time")

        sub_c = input(f"\n{BOLD}{NEON_PURPLE}[>] Choice (1 / 2):{RESET} ").strip()
        target_ts = int(time.time())

        if sub_c == "2":
            user_dt_str = input(f"{BOLD}{WHITE}Enter Date/Time (Format: YYYY-MM-DD HH:MM:SS) e.g. 2026-12-31 23:59:59:{RESET} ").strip()
            try:
                dt_obj = datetime.datetime.strptime(user_dt_str, "%Y-%m-%d %H:%M:%S")
                target_ts = int(dt_obj.timestamp())
            except ValueError:
                status_msg("!", "Invalid date format. Using current timestamp instead.", YELLOW)

        ts = target_ts
        tags = {
            f"<t:{ts}:t>": "Short Time (e.g. 16:20)",
            f"<t:{ts}:T>": "Long Time (e.g. 16:20:30)",
            f"<t:{ts}:d>": "Short Date (e.g. 10/08/2026)",
            f"<t:{ts}:D>": "Long Date (e.g. October 8, 2026)",
            f"<t:{ts}:f>": "Short Date & Time (e.g. October 8, 2026 16:20)",
            f"<t:{ts}:F>": "Long Date & Time (e.g. Thursday, October 8, 2026 16:20)",
            f"<t:{ts}:R>": "Relative Time (e.g. in 2 hours / 5 minutes ago)"
        }

        print(f"\n{BOLD}{NEON_PURPLE}[◈] GENERATED DISCORD TIMESTAMP CODES:{RESET}")
        report_lines = [
            "==================================================",
            "ASPECT DISCORD SUITE - DYNAMIC TIMESTAMP CODES",
            "==================================================",
            f"Target Unix Timestamp: {ts}\n"
        ]
        for tag, desc in tags.items():
            print(f"  {NEON_PINK}{tag:<16}{RESET} {CYAN}→{RESET} {WHITE}{desc}{RESET}")
            report_lines.append(f"{tag:<16} -> {desc}")

        report_lines.append("\n==================================================")
        save_txt_report(f"TIMESTAMPS_{ts}", "\n".join(report_lines))

    else:
        md_examples = [
            ("Bold Text", "**Bold Text**"),
            ("Italic Text", "*Italic* or _Italic_"),
            ("Underline Text", "__Underlined Text__"),
            ("Strikethrough Text", "~~Strikethrough Text~~"),
            ("Spoiler Block", "||Hidden Spoiler Text||"),
            ("Inline Code", "`python print('Hello')`"),
            ("Multi-line Code Block", "```python\ndef hello():\n    print('World')\n```"),
            ("Blockquote", "> Single line blockquote\n>>> Multi-line blockquote"),
            ("Subtext", "-# Small subtext note"),
            ("Headers", "# Header 1\n## Header 2\n### Header 3")
        ]

        print(f"\n{BOLD}{NEON_PURPLE}[◈] DISCORD MARKDOWN CHAT FORMATTING:{RESET}")
        report_lines = [
            "==================================================",
            "ASPECT DISCORD SUITE - MARKDOWN FORMATTING GUIDE",
            "=================================================="
        ]
        for name, syntax in md_examples:
            print(f"\n  {BOLD}{NEON_PINK}• {name}:{RESET}")
            print(f"    {WHITE}{syntax}{RESET}")
            report_lines.append(f"\n• {name}:\n{syntax}")

        report_lines.append("\n==================================================")
        save_txt_report("MARKDOWN_CHEAT_SHEET", "\n".join(report_lines))

# -----------------------------------------------------------------------------
# 6. Server Widget & Asset Inspector
# -----------------------------------------------------------------------------
async def async_fetch_widget(guild_id: str) -> Dict[str, Any]:
    url = f"https://discord.com/api/v10/guilds/{guild_id}/widget.json"
    headers = {"User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"}
    conn = aiohttp.TCPConnector(ssl=False)
    async with aiohttp.ClientSession(connector=conn) as session:
        try:
            async with session.get(url, headers=headers, timeout=aiohttp.ClientTimeout(total=8)) as resp:
                text = await resp.text()
                if "erisime_engellenmis" in text or (resp.status == 200 and "<html" in text.lower()):
                    return {"success": False, "error": "Cannot connect to Discord API (ISP/DNS Restriction)."}
                if resp.status == 200:
                    try:
                        return {"success": True, "data": json.loads(text)}
                    except json.JSONDecodeError:
                        return {"success": False, "error": "Invalid JSON response received."}
                elif resp.status == 403:
                    return {"success": False, "error": "Public Server Widget is disabled on this server."}
                elif resp.status == 404:
                    return {"success": False, "error": "Server or Widget not found."}
                else:
                    return {"success": False, "error": f"HTTP Error: {resp.status}"}
        except Exception as e:
            return {"success": False, "error": f"Connection error: {str(e)}"}

def run_widget_inspector():
    section_header("DISCORD SUITE: SERVER WIDGET & ASSET INSPECTOR")
    guild_id = input(f"{BOLD}{NEON_PURPLE}[>] Enter Server (Guild) ID:{RESET} ").strip()
    if not guild_id.isdigit():
        status_msg("!", "Please enter a valid numeric Guild ID.", RED)
        input(f"\n{GRAY}Press Enter to continue...{RESET}")
        return

    sf = decode_snowflake(int(guild_id))

    status_msg("*", f"Querying Public Widget data for Guild ID '{guild_id}'...", CYAN)
    res = asyncio.run(async_fetch_widget(guild_id))

    report_lines = [
        "==================================================",
        "ASPECT OSINT SUITE - SERVER WIDGET & ASSETS",
        "==================================================",
        f"Guild ID      : {guild_id}",
        f"Creation Date : {sf.get('dt_utc', 'N/A')}",
        f"Server Age    : {sf.get('age_str', 'N/A')}"
    ]

    if not res["success"]:
        status_msg("!", res["error"], YELLOW)
        print(f"\n{BOLD}{NEON_PURPLE}[◈] ESTIMATED DIRECT CDN ASSET URL FORMATS:{RESET}")
        print(f"  {NEON_PINK}• Icon Format:{RESET} {WHITE}https://cdn.discordapp.com/icons/{guild_id}/[HASH].png{RESET}")
        print(f"  {NEON_PINK}• Banner Format:{RESET} {WHITE}https://cdn.discordapp.com/banners/{guild_id}/[HASH].png{RESET}")
        report_lines.append(f"Widget Status : DISABLED / UNAVAILABLE ({res['error']})")
    else:
        d = res["data"]
        name = d.get("name", "Unknown")
        instant_invite = d.get("instant_invite") or "None"
        presence_count = d.get("presence_count", 0)
        members = d.get("members", [])

        print(f"\n{BOLD}{NEON_PURPLE}[◈] PUBLIC WIDGET SERVER DETAILS:{RESET}")
        key_val("Server Name", name)
        key_val("Server ID", guild_id)
        if sf.get("valid"):
            key_val("Creation Date", sf["dt_utc"])
        key_val("Active Online Members", str(presence_count))
        key_val("Instant Invite Link", instant_invite)

        report_lines.extend([
            f"Server Name   : {name}",
            f"Active Online : {presence_count}",
            f"Invite Link   : {instant_invite}",
            f"\n--- Voice / Active User List ({len(members)}) ---"
        ])

        if members:
            print(f"\n{BOLD}{NEON_PURPLE}[◈] ACTIVE MEMBERS VISIBLE ON WIDGET ({len(members)}):{RESET}")
            for m in members[:10]:
                username = m.get("username")
                status = m.get("status")
                channel = m.get("channel_id") or "Main Screen"
                print(f"  {CYAN}• {username:<20}{RESET} Status: {GREEN}{status:<8}{RESET} | Channel ID: {GRAY}{channel}{RESET}")
                report_lines.append(f"• {username:<20} Status: {status:<8} | Channel: {channel}")
            if len(members) > 10:
                print(f"  {GRAY}... and {len(members) - 10} more members{RESET}")

    report_lines.append("==================================================")
    save_txt_report(f"WIDGET_{guild_id}", "\n".join(report_lines))

# -----------------------------------------------------------------------------
# 7. API Latency & Connection Tester
# -----------------------------------------------------------------------------
async def async_probe_endpoint(session: aiohttp.ClientSession, name: str, url: str) -> Dict[str, Any]:
    times = []
    statuses = []

    for _ in range(5):
        start = time.perf_counter()
        try:
            async with session.get(url, timeout=aiohttp.ClientTimeout(total=5)) as resp:
                elapsed = (time.perf_counter() - start) * 1000
                times.append(elapsed)
                statuses.append(resp.status)
        except Exception:
            statuses.append(0)
        await asyncio.sleep(0.1)

    if times:
        min_t = min(times)
        max_t = max(times)
        avg_t = sum(times) / len(times)
        success_rate = (len(times) / 5) * 100
        return {
            "name": name,
            "url": url,
            "min": min_t,
            "max": max_t,
            "avg": avg_t,
            "status": statuses[-1] if statuses else 0,
            "success_rate": success_rate
        }
    else:
        return {"name": name, "url": url, "min": 0, "max": 0, "avg": 0, "status": 0, "success_rate": 0}

async def run_all_latency_tests() -> List[Dict[str, Any]]:
    endpoints = [
        ("REST API Gateway", "https://discord.com/api/v10/gateway"),
        ("Asset CDN", "https://cdn.discordapp.com"),
        ("Media CDN", "https://media.discordapp.net"),
        ("Status API", "https://discordstatus.com/api/v2/summary.json")
    ]
    headers = {"User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"}
    results = []
    conn = aiohttp.TCPConnector(ssl=False)
    async with aiohttp.ClientSession(connector=conn, headers=headers) as session:
        tasks = [async_probe_endpoint(session, name, url) for name, url in endpoints]
        results = await asyncio.gather(*tasks)
    return results

def run_api_latency_tester():
    section_header("DISCORD SUITE: API LATENCY & CONNECTION TESTER")
    status_msg("*", "Measuring real-time connection latency (ping) to Discord REST API and CDN services...", CYAN)

    results = asyncio.run(run_all_latency_tests())

    print(f"\n{BOLD}{NEON_PURPLE}[◈] DISCORD API REGIONAL PING & LATENCY RESULTS:{RESET}\n")
    print(f"  {BOLD}{WHITE}{'Service / Endpoint':<24} {'Min':<8} {'Max':<8} {'Average':<10} {'HTTP':<8} {'Status':<10}{RESET}")
    print(f"  {DARK_PURPLE}{'━' * 70}{RESET}")

    report_lines = [
        "==================================================",
        "ASPECT DISCORD SUITE - API LATENCY TEST REPORT",
        "==================================================",
        f"Test Date: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n",
        f"{'Service':<22} {'Min (ms)':<10} {'Max (ms)':<10} {'Avg (ms)':<10} {'HTTP':<6}"
    ]

    for r in results:
        avg = r["avg"]
        if r["status"] == 200:
            if avg < 100:
                badge = f"{GREEN}[ EXCELLENT ]{RESET}"
            elif avg < 250:
                badge = f"{YELLOW}[ GOOD ]{RESET}"
            else:
                badge = f"{RED}[ HIGH ]{RESET}"
        else:
            badge = f"{RED}[ NO CONNECTION ]{RESET}"

        print(f"  {NEON_PINK}{r['name']:<24}{RESET} {WHITE}{r['min']:<8.1f} {r['max']:<8.1f} {r['avg']:<10.1f} {r['status']:<8}{RESET} {badge}")
        report_lines.append(f"{r['name']:<22} {r['min']:<10.1f} {r['max']:<10.1f} {r['avg']:<10.1f} {r['status']:<6}")

    report_lines.append("==================================================")
    save_txt_report("API_LATENCY", "\n".join(report_lines))

# -----------------------------------------------------------------------------
# 8. ID List Cleaner & Chronological Sorter
# -----------------------------------------------------------------------------
def run_id_cleaner_sorter():
    section_header("DISCORD SUITE: ID LIST CLEANER & CHRONOLOGICAL SORTER")
    print(f"{CYAN}Paste your Discord ID list into terminal or enter a file path:{RESET}")
    print(f"{GRAY}(Type 'END' on a new line or use Ctrl+D when finished){RESET}\n")

    lines = []
    while True:
        try:
            line = input()
            if line.strip().upper() == "END":
                break
            lines.append(line)
        except (EOFError, KeyboardInterrupt):
            break

    raw_text = "\n".join(lines)

    if os.path.exists(raw_text.strip()):
        try:
            with open(raw_text.strip(), "r", encoding="utf-8") as f:
                raw_text = f.read()
        except Exception as e:
            status_msg("!", f"Error reading file: {e}", RED)
            input(f"\n{GRAY}Press Enter to continue...{RESET}")
            return

    raw_ids = re.findall(r'\b\d{17,20}\b', raw_text)
    if not raw_ids:
        status_msg("!", "No valid 17-20 digit Discord ID found in input.", RED)
        input(f"\n{GRAY}Press Enter to continue...{RESET}")
        return

    unique_ids = list(dict.fromkeys(raw_ids))
    parsed_items = []

    for sf_str in unique_ids:
        sf_int = int(sf_str)
        dec = decode_snowflake(sf_int)
        if dec["valid"]:
            parsed_items.append(dec)

    parsed_items.sort(key=lambda x: x["timestamp_ms"])

    print(f"\n{BOLD}{NEON_PURPLE}[◈] CLEANED & CHRONOLOGICALLY SORTED DISCORD ID LIST:{RESET}")
    print(f"  {GRAY}Total IDs Found: {len(raw_ids)} | Unique IDs: {len(unique_ids)}{RESET}\n")
    print(f"  {BOLD}{WHITE}{'Index':<6} {'Discord Snowflake ID':<22} {'Creation Date (UTC)':<24} {'Entity Age'}{RESET}")
    print(f"  {DARK_PURPLE}{'━' * 75}{RESET}")

    report_lines = [
        "==================================================",
        "ASPECT DISCORD SUITE - CLEANED & SORTED ID LIST",
        "==================================================",
        f"Total Found : {len(raw_ids)}",
        f"Unique IDs  : {len(unique_ids)}\n",
        f"{'Index':<6} {'Discord ID':<22} {'Creation (UTC)':<24} {'Age'}"
    ]

    for idx, item in enumerate(parsed_items, 1):
        print(f"  {NEON_PINK}#{idx:<5}{RESET} {WHITE}{item['id']:<22}{RESET} {CYAN}{item['dt_utc']:<24}{RESET} {GRAY}{item['age_str']}{RESET}")
        report_lines.append(f"#{idx:<5} {item['id']:<22} {item['dt_utc']:<24} {item['age_str']}")

    report_lines.append("\n=== RAW CLEANED ID LIST ===")
    for item in parsed_items:
        report_lines.append(str(item['id']))

    report_lines.append("==================================================")
    save_txt_report("CLEANED_SORTED_IDS", "\n".join(report_lines))


# -----------------------------------------------------------------------------
# Main Module Entry Point for Page 4 (Discord Checker)
# -----------------------------------------------------------------------------
def run_discord_suite(choice: str):
    """Routes sub-menu choices for Page 4 Discord Checker."""
    if choice in ["1", "01"]:
        run_invite_analyzer()
    elif choice in ["2", "02"]:
        run_webhook_sender()
    elif choice in ["3", "03"]:
        run_snowflake_decrypter()
    elif choice in ["4", "04"]:
        run_bot_inspector()
    elif choice in ["5", "05"]:
        run_markdown_generator()
    elif choice in ["6", "06"]:
        run_widget_inspector()
    elif choice in ["7", "07"]:
        run_api_latency_tester()
    elif choice in ["8", "08"]:
        run_id_cleaner_sorter()
    else:
        status_msg("!", "Invalid choice! Please select a module between 1 and 8.", RED)
        time.sleep(1.2)
