"""
Module 1: Username Search (Username OSINT)
Searches across TikTok, Instagram, Facebook, Twitter (X), Pinterest,
Reddit, Snapchat, Telegram, Discord, and GitHub when a username is entered,
and opens all these platforms in tabs in the device's default browser for inspection.
"""

import time
import webbrowser
import requests
from utils.colors import (
    c, status_msg, section_header, key_val,
    NEON_PURPLE, NEON_PINK, CYAN, GREEN, YELLOW, RED, WHITE, GRAY, RESET, BOLD
)

PLATFORMS = [
    {"name": "TikTok", "url": "https://www.tiktok.com/@{username}"},
    {"name": "Instagram", "url": "https://www.instagram.com/{username}/"},
    {"name": "Facebook", "url": "https://www.facebook.com/{username}"},
    {"name": "Twitter / X", "url": "https://x.com/{username}"},
    {"name": "Pinterest", "url": "https://www.pinterest.com/{username}/"},
    {"name": "Reddit", "url": "https://www.reddit.com/user/{username}"},
    {"name": "Snapchat", "url": "https://www.snapchat.com/add/{username}"},
    {"name": "Telegram", "url": "https://t.me/{username}"},
    {"name": "Discord", "url": "https://discord.com/users/{username}"},
    {"name": "GitHub", "url": "https://github.com/{username}"},
]

def check_single_platform(name: str, url: str) -> str:
    """Quick HTTP header check."""
    headers = {
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    }
    try:
        resp = requests.get(url, headers=headers, timeout=4, allow_redirects=True)
        if resp.status_code == 200:
            return f"{GREEN}[200 OK - Active / May Exist]{RESET}"
        elif resp.status_code == 404:
            return f"{RED}[404 - Not Found]{RESET}"
        else:
            return f"{YELLOW}[HTTP {resp.status_code}]{RESET}"
    except Exception:
        return f"{GRAY}[Connection Failed / Opened Directly in Browser]{RESET}"

def run_username_osint():
    section_header("1. USERNAME SEARCH (USERNAME OSINT)")
    print(f"{GRAY}Target platforms: TikTok, Instagram, Facebook, Twitter, Pinterest, Reddit, Snapchat, Telegram, Discord, GitHub{RESET}\n")

    username = input(f"{BOLD}{NEON_PURPLE}[>] Username to Search:{RESET} ").strip()
    if not username:
        status_msg("!", "Username cannot be empty.", RED)
        input(f"\n{GRAY}Press Enter to continue...{RESET}")
        return

    status_msg("*", f"Preparing platform links for '{username}' and opening in browser...", CYAN)
    print()

    for item in PLATFORMS:
        target_url = item["url"].format(username=username)
        print(f"  {NEON_PINK}• {item['name']:<14}{RESET} -> {WHITE}{target_url}{RESET}")
        try:
            webbrowser.open_new_tab(target_url)
            time.sleep(0.2)  # Short delay to prevent browser freeze
        except Exception as e:
            print(f"    {RED}Failed to open browser: {e}{RESET}")

    print(f"\n{GREEN}[✓] All platforms opened in your default browser!{RESET}")
    print(f"{GRAY}You can inspect profiles and content individually from the opened tabs.{RESET}")

    input(f"\n{NEON_PURPLE}[⏎] Press Enter to return to main menu...{RESET}")
