"""
Module 6: GitHub OSINT (Public REST API)
- User profile (Name, Bio, Company, Location, Followers, etc.)
- Public repository list (Stars, languages, descriptions)
- Commit information and activity analysis
- Commit author public email and domain traces
- Sensitive information leak analysis in repositories and commits (Public content)
"""

import re
import requests

from utils.colors import (
    c, status_msg, section_header, key_val,
    NEON_PURPLE, NEON_PINK, CYAN, GREEN, YELLOW, RED, WHITE, GRAY, RESET, BOLD
)

HEADERS = {
    "Accept": "application/vnd.github.v3+json",
    "User-Agent": "ASPECT-OSINT-Tool"
}

SENSITIVE_PATTERNS = [
    r"api[_-]?key",
    r"secret",
    r"token",
    r"password",
    r"passwd",
    r"bearer",
    r"BEGIN\s+(RSA|OPENSSH|DSA|EC)\s+PRIVATE\s+KEY",
    r"\.env\b",
    r"credential"
]

def run_github_osint():
    section_header("6. GITHUB OSINT")
    username = input(f"{BOLD}{NEON_PURPLE}[>] GitHub Username:{RESET} ").strip()
    if not username:
        status_msg("!", "Username cannot be empty.", RED)
        input(f"\n{GRAY}Press Enter to continue...{RESET}")
        return

    status_msg("*", f"Scanning '{username}' profile via GitHub API...", CYAN)

    # 1. Profile Information
    user_url = f"https://api.github.com/users/{username}"
    try:
        r = requests.get(user_url, headers=HEADERS, timeout=8)
        if r.status_code == 404:
            status_msg("!", f"GitHub user '{username}' not found.", RED)
            input(f"\n{GRAY}Press Enter to continue...{RESET}")
            return
        elif r.status_code == 403:
            status_msg("!", "GitHub API rate limit reached. Please try again later.", YELLOW)
            input(f"\n{GRAY}Press Enter to continue...{RESET}")
            return
        profile = r.json()
    except Exception as e:
        status_msg("!", f"Connection error: {e}", RED)
        input(f"\n{GRAY}Press Enter to continue...{RESET}")
        return

    print()
    print(f"{BOLD}{NEON_PURPLE}[1] GitHub User Profile:{RESET}")
    key_val("Username", profile.get("login", "-"))
    key_val("Full Name", profile.get("name") or "Not specified")
    key_val("Biography", profile.get("bio") or "Not specified")
    key_val("Company / Organization", profile.get("company") or "Not specified")
    key_val("Location", profile.get("location") or "Not specified")
    key_val("Website / Blog", profile.get("blog") or "Not specified")
    key_val("Twitter", profile.get("twitter_username") or "Not specified")
    key_val("Public Email", profile.get("email") or "Hidden on profile")
    key_val("Public Repos Count", str(profile.get("public_repos", 0)))
    key_val("Followers / Following", f"{profile.get('followers', 0)} / {profile.get('following', 0)}")
    key_val("Registration Date", profile.get("created_at", "-")[:10])
    key_val("Profile URL", profile.get("html_url", "-"))

    # 2. Public Repositories
    print(f"\n{BOLD}{NEON_PURPLE}[2] Public Repositories (Recently Updated):{RESET}")
    repos_url = f"https://api.github.com/users/{username}/repos?sort=updated&per_page=10"
    repos = []
    try:
        rr = requests.get(repos_url, headers=HEADERS, timeout=8)
        if rr.status_code == 200:
            repos = rr.json()
            for repo in repos:
                name = repo.get("name")
                lang = repo.get("language") or "Not specified"
                stars = repo.get("stargazers_count", 0)
                forks = repo.get("forks_count", 0)
                desc = repo.get("description") or "No description"
                print(f"  {CYAN}• {name:<22}{RESET} [{YELLOW}★ {stars}{RESET} | ⑂ {forks}] Language: {GREEN}{lang:<12}{RESET}")
                print(f"    {GRAY}{desc[:75]}{'...' if len(desc) > 75 else ''}{RESET}")
        else:
            print(f"  {YELLOW}Failed to retrieve repository list.{RESET}")
    except Exception as e:
        print(f"  {RED}Repository fetch error: {e}{RESET}")

    # 3. Public Events, Commit Info and Email / Domain Traces
    print(f"\n{BOLD}{NEON_PURPLE}[3] Commit Info & Public Email/Domain Traces:{RESET}")
    events_url = f"https://api.github.com/users/{username}/events/public?per_page=30"
    discovered_emails = set()
    commit_messages = []

    try:
        er = requests.get(events_url, headers=HEADERS, timeout=8)
        if er.status_code == 200:
            events = er.json()
            for ev in events:
                if ev.get("type") == "PushEvent":
                    payload = ev.get("payload", {})
                    for commit in payload.get("commits", []):
                        author = commit.get("author", {})
                        email = author.get("email")
                        name = author.get("name")
                        msg = commit.get("message", "")
                        commit_messages.append((commit.get("sha", "")[:7], msg))

                        if email and "noreply.github.com" not in email:
                            discovered_emails.add((email, name))

            if discovered_emails:
                print(f"  {GREEN}[✓] Real email traces detected from public commits:{RESET}")
                for em, nm in discovered_emails:
                    print(f"    {WHITE}• Email:{RESET} {NEON_PINK}{em}{RESET} {GRAY}(Name: {nm}){RESET}")
            else:
                print(f"  {GRAY}[-] No public email found in commits or 'noreply' privacy is active.{RESET}")
        else:
            print(f"  {GRAY}[-] No public activity records found.{RESET}")
    except Exception as e:
        print(f"  {RED}Activity query error: {e}{RESET}")

    # 4. Sensitive Information Leak Detection (Public commit and repo data only)
    print(f"\n{BOLD}{NEON_PURPLE}[4] Sensitive Data Trace Scan in Public Content:{RESET}")
    findings = []
    
    # Scan commit messages
    for sha, msg in commit_messages:
        for pat in SENSITIVE_PATTERNS:
            if re.search(pat, msg, re.IGNORECASE):
                findings.append((sha, msg.strip()))
                break

    if findings:
        print(f"  {YELLOW}[!] Suspicious commit messages detected:{RESET}")
        for sha, msg in findings[:6]:
            print(f"    {RED}• [{sha}]{RESET} {WHITE}{msg[:70]}{RESET}")
        print(f"    {GRAY}(These commits may have accidentally leaked public secrets/keys in their history){RESET}")
    else:
        print(f"  {GREEN}[✓] No prominent sensitive keyword traces found in recent public commit messages.{RESET}")

    input(f"\n{NEON_PURPLE}[⏎] Press Enter to return to main menu...{RESET}")
