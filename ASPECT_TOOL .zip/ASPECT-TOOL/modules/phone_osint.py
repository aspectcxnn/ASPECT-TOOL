"""
Module 5: Phone Number OSINT
- Country code and country name
- Carrier information (network operator detection)
- Number format and validity verification (E.164, International, National)
- Timezone and line type (Mobile, Fixed Line, VOIP)
- Public web searches and search dorks
"""

import urllib.parse
import webbrowser
import phonenumbers
from phonenumbers import geocoder, carrier, timezone, PhoneNumberType

from utils.colors import (
    c, status_msg, section_header, key_val,
    NEON_PURPLE, NEON_PINK, CYAN, GREEN, YELLOW, RED, WHITE, GRAY, RESET, BOLD
)

def get_number_type_str(num_type: int) -> str:
    types = {
        PhoneNumberType.MOBILE: "Mobile Line",
        PhoneNumberType.FIXED_LINE: "Fixed Line",
        PhoneNumberType.FIXED_LINE_OR_MOBILE: "Fixed or Mobile Line",
        PhoneNumberType.TOLL_FREE: "Toll-Free Line",
        PhoneNumberType.PREMIUM_RATE: "Premium Rate Line",
        PhoneNumberType.SHARED_COST: "Shared Cost Line",
        PhoneNumberType.VOIP: "Internet Phone (VoIP)",
        PhoneNumberType.PERSONAL_NUMBER: "Personal Number",
        PhoneNumberType.PAGER: "Pager",
        PhoneNumberType.UAN: "Universal Access Number (UAN)",
        PhoneNumberType.VOICEMAIL: "Voicemail Box"
    }
    return types.get(num_type, "Unknown Type")

def run_phone_osint():
    section_header("5. PHONE NUMBER OSINT")
    print(f"{GRAY}Enter number in international format (e.g., +905551234567 or +14155552671){RESET}\n")

    raw_phone = input(f"{BOLD}{NEON_PURPLE}[>] Phone Number:{RESET} ").strip()
    if not raw_phone:
        status_msg("!", "Number cannot be empty.", RED)
        input(f"\n{GRAY}Press Enter to continue...{RESET}")
        return

    # If it doesn't start with +, add it by default
    if not raw_phone.startswith("+"):
        raw_phone = "+" + raw_phone

    try:
        parsed = phonenumbers.parse(raw_phone, None)
    except Exception as e:
        status_msg("!", f"Number could not be parsed: {e}", RED)
        input(f"\n{GRAY}Press Enter to continue...{RESET}")
        return

    is_valid = phonenumbers.is_valid_number(parsed)
    is_possible = phonenumbers.is_possible_number(parsed)

    print()
    # 1. Format and Validity
    print(f"{BOLD}{NEON_PURPLE}[1] Number Format & Validity Check:{RESET}")
    status_str = f"{GREEN}Valid and Active Format{RESET}" if is_valid else f"{RED}Invalid Number{RESET}"
    possible_str = f"{GREEN}Possible Number{RESET}" if is_possible else f"{RED}Not Possible{RESET}"
    key_val("Validity Status", status_str)
    key_val("Format Check", possible_str)
    
    e164_fmt = phonenumbers.format_number(parsed, phonenumbers.PhoneNumberFormat.E164)
    intl_fmt = phonenumbers.format_number(parsed, phonenumbers.PhoneNumberFormat.INTERNATIONAL)
    nat_fmt = phonenumbers.format_number(parsed, phonenumbers.PhoneNumberFormat.NATIONAL)

    key_val("E.164 Format", e164_fmt)
    key_val("International Format", intl_fmt)
    key_val("National Format", nat_fmt)

    # 2. Country & Region
    print(f"\n{BOLD}{NEON_PURPLE}[2] Geographical and Country Info:{RESET}")
    key_val("Country Code", f"+{parsed.country_code}")
    
    country_desc_en = geocoder.description_for_number(parsed, "en")
    country_desc_tr = geocoder.description_for_number(parsed, "tr")
    country_display = country_desc_en or country_desc_tr or "Unknown"
    key_val("Country / Location", country_display)

    tz_list = timezone.time_zones_for_number(parsed)
    key_val("Timezone", ", ".join(tz_list) if tz_list else "Unknown")

    # 3. Carrier & Line Type
    print(f"\n{BOLD}{NEON_PURPLE}[3] Carrier and Line Type:{RESET}")
    num_type = phonenumbers.number_type(parsed)
    key_val("Line Type", get_number_type_str(num_type))

    carrier_en = carrier.name_for_number(parsed, "en")
    carrier_tr = carrier.name_for_number(parsed, "tr")
    carrier_display = carrier_en or carrier_tr or "Carrier Not Found in Database / Prepaid"
    key_val("Carrier (Network)", carrier_display)

    # 4. Public Web Searches and Dorks
    print(f"\n{BOLD}{NEON_PURPLE}[4] Public Web Search Dorks:{RESET}")
    dorks = [
        f'"{e164_fmt}"',
        f'"{intl_fmt}"',
        f'"{nat_fmt}"',
        f'"{e164_fmt}" site:facebook.com OR site:instagram.com OR site:linkedin.com',
        f'"{e164_fmt}" site:t.me OR site:wa.me'
    ]

    for d in dorks:
        link = f"https://www.google.com/search?q={urllib.parse.quote(d)}"
        print(f"  {CYAN}• Dork:{RESET} {WHITE}{d:<45}{RESET} {GRAY}-> {link}{RESET}")

    open_choice = input(f"\n{BOLD}{NEON_PINK}[?] Open search link in browser? (y/n):{RESET} ").strip().lower()
    if open_choice in ['y', 'yes']:
        webbrowser.open_new_tab(f"https://www.google.com/search?q={urllib.parse.quote(f'\"{e164_fmt}\"')}")
        print(f"{GREEN}[✓] Search opened in browser.{RESET}")

    input(f"\n{NEON_PURPLE}[⏎] Press Enter to return to main menu...{RESET}")
