"""
Module: Gift Card Generator (Terminal Live Stream)
Completely synthetic and for simulation purposes only.
Does not contain real validation mechanisms or API connections.
"""

import sys
import time
import random
from datetime import datetime

from utils.banner import clear_screen
from utils.colors import (
    c, status_msg, section_header,
    NEON_PURPLE, DEEP_PURPLE, DARK_PURPLE, NEON_PINK,
    CYAN, GREEN, YELLOW, RED, WHITE, GRAY, DARK_GRAY, RESET, BOLD
)

CHARS = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"

def rand_str(length: int, chars: str = CHARS) -> str:
    """Generates a random synthetic string from the specified character set."""
    return "".join(random.choice(chars) for _ in range(length))

# Exact 8 Platform Definitions
PLATFORMS = {
    "1": {
        "id": "PLAY_STORE",
        "name": "Play Store",
        "gen": lambda: f"{rand_str(4)}-{rand_str(4)}-{rand_str(4)}-{rand_str(4)}-{rand_str(4)}"
    },
    "2": {
        "id": "APP_STORE",
        "name": "App Store",
        "gen": lambda: f"X{rand_str(3)}-{rand_str(4)}-{rand_str(4)}-{rand_str(4)}"
    },
    "3": {
        "id": "AMAZON",
        "name": "Amazon Gift",
        "gen": lambda: f"{rand_str(4)}-{rand_str(6)}-{rand_str(5)}"
    },
    "4": {
        "id": "NETFLIX",
        "name": "Netflix Gift",
        "gen": lambda: f"{rand_str(4)}-{rand_str(4)}-{rand_str(4)}"
    },
    "5": {
        "id": "STEAM",
        "name": "Steam Gift",
        "gen": lambda: f"{rand_str(5)}-{rand_str(5)}-{rand_str(5)}"
    },
    "6": {
        "id": "SPOTIFY",
        "name": "Spotify Gift",
        "gen": lambda: f"{rand_str(4)}-{rand_str(5)}-{rand_str(5)}"
    },
    "7": {
        "id": "DISCORD",
        "name": "Discord Nitro",
        "gen": lambda: f"discord.gift/{rand_str(16)}"
    },
    "8": {
        "id": "XBOX",
        "name": "Xbox Gift",
        "gen": lambda: f"{rand_str(5)}-{rand_str(5)}-{rand_str(5)}-{rand_str(5)}-{rand_str(5)}"
    }
}

def run_giftcard_generator(choice: str):
    """
    Starts a live, continuous simulation on the terminal for the selected platform.
    Does not ask for quantity or UI, starts directly in the terminal.
    Only stops when the user presses Ctrl+C or when 1/1000 simulated FOUND occurs.
    """
    choice = choice.strip()
    if choice not in PLATFORMS:
        status_msg("!", "Invalid platform selection!", RED)
        time.sleep(1)
        return

    p_obj = PLATFORMS[choice]

    clear_screen()
    section_header(f"GIFT CARD GENERATOR - {p_obj['name'].upper()}")
    print(f" {BOLD}{CYAN}Target Platform:{RESET} {WHITE}{p_obj['name']}{RESET}")
    print(f" {BOLD}{YELLOW}Status:{RESET} {GREEN}Automatic generation started. (To stop: Ctrl+C){RESET}")
    print(f" {DARK_GRAY}Notice: Stops on 1/1000 simulated 'FOUND' or Ctrl+C. No real validation is performed.{RESET}\n")

    # Table header
    print(f"{DARK_PURPLE}{'━'*75}{RESET}")
    print(f"{BOLD}{NEON_PINK}{'# NO':<8} {'TIME':<10} {'PLATFORM':<16} {'SYNTHETIC CODE':<28} {'STATUS'}{RESET}")
    print(f"{DARK_PURPLE}{'━'*75}{RESET}")

    total_count = 0
    start_time = time.time()

    try:
        while True:
            total_count += 1
            code = p_obj["gen"]()
            now_str = datetime.now().strftime("%H:%M:%S")

            # 1/1000 FOUND simulation
            is_found = (random.random() < 0.001)

            if is_found:
                # When FOUND occurs, immediately stop generation and highlight
                print(f"\a", end="") # Terminal audio alert
                print(f"\n{GREEN}{'━'*75}{RESET}")
                print(f"{BOLD}{GREEN}[★ FOUND ★]{RESET} {WHITE}#{total_count:<6} {now_str:<8} {p_obj['name']:<15} {code:<26} {GREEN}[FOUND]{RESET}")
                print(f"{GREEN}{'━'*75}{RESET}\n")

                print(f"{BOLD}{GREEN}╔═══════════════════════════════════════════════════════════════════╗{RESET}")
                print(f"{BOLD}{GREEN}║                       ★ SIMULATED FOUND! ★                        ║{RESET}")
                print(f"{BOLD}{GREEN}╚═══════════════════════════════════════════════════════════════════╝{RESET}")
                print(f"  {CYAN}Platform  :{RESET} {WHITE}{p_obj['name']}{RESET}")
                print(f"  {NEON_PINK}Code      :{RESET} {BOLD}{WHITE}{code}{RESET}")
                print(f"  {YELLOW}Order     :{RESET} {WHITE}Captured at generation #{total_count}.{RESET}")
                print(f"  {GRAY}Info      : 1/1000 simulation probability occurred and stream was stopped.{RESET}")
                print(f"  {DARK_GRAY}Note      : No real gift card validation was performed.{RESET}\n")
                break
            else:
                # Normal row - smooth, readable speed
                status_str = f"{GRAY}[CHECKED]{RESET}"
                print(f"{WHITE}#{total_count:<7}{RESET} {GRAY}{now_str:<9}{RESET} {CYAN}{p_obj['name']:<15}{RESET} {BOLD}{WHITE}{code:<27}{RESET} {status_str}")

            # Delay to generate ~3 codes per second (330ms)
            time.sleep(0.33)

    except KeyboardInterrupt:
        elapsed = time.time() - start_time
        print(f"\n\n{BOLD}{YELLOW}[STOP]{RESET} {WHITE}Stopped by user.{RESET}")
        print(f"  {CYAN}Total Generated Codes :{RESET} {WHITE}{total_count}{RESET}")
        print(f"  {NEON_PINK}Elapsed Time          :{RESET} {WHITE}{elapsed:.1f} seconds{RESET}\n")

    input(f"{GRAY}Press Enter to return to menu...{RESET}")
