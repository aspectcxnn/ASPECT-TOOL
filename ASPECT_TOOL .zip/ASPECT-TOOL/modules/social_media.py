"""
Module: Social Media Accounts (Page 1)
Displays official developer and suite social media accounts & links.
"""

import sys
import time
from utils.colors import (
    c, status_msg, section_header, key_val,
    NEON_PURPLE, DEEP_PURPLE, DARK_PURPLE, NEON_PINK, HOT_PINK,
    CYAN, GREEN, YELLOW, RED, WHITE, GRAY, DARK_GRAY, RESET, BOLD
)

SOCIAL_ACCOUNTS = {
    "1": {
        "platform": "Telegram",
        "handle": "@egoaspect",
        "url": "https://t.me/egoaspect",
        "description": "Official Telegram Channel & Community"
    },
    "2": {
        "platform": "Discord",
        "handle": "@cellatinim",
        "url": "Discord User Tag: @cellatinim",
        "description": "Developer Discord Contact"
    },
    "3": {
        "platform": "TikTok",
        "handle": "@aspectcxnn",
        "url": "https://tiktok.com/@aspectcxnn",
        "description": "Official TikTok Profile & Content"
    },
    "4": {
        "platform": "GitHub",
        "handle": "@aspectcxnn",
        "url": "https://github.com/aspectcxnn",
        "description": "Official GitHub Repository & Projects"
    },
    "5": {
        "platform": "X (Twitter)",
        "handle": "@egoaspect",
        "url": "https://x.com/egoaspect",
        "description": "Official X / Twitter Profile"
    }
}

def display_social_account(choice: str):
    """Displays formatted card for the selected social media account."""
    acc = SOCIAL_ACCOUNTS.get(choice)
    if not acc:
        status_msg("!", "Invalid choice! Please select a valid social media option.", RED)
        time.sleep(1.2)
        return

    section_header(f"SOCIAL MEDIA: {acc['platform'].upper()}")
    print(f"\n{BOLD}{NEON_PURPLE}[◈] OFFICIAL ACCOUNT INFORMATION:{RESET}")
    key_val("Platform", acc["platform"])
    key_val("Handle / Username", acc["handle"])
    key_val("Direct Link / Tag", acc["url"])
    key_val("Description", acc["description"])
    print(f"\n{DARK_PURPLE}{'━' * 60}{RESET}")
    input(f"{NEON_PURPLE}[⏎] Press Enter to return to main menu...{RESET}")

def run_social_media(choice: str):
    """Entry point for Page 1 Social Media menu choices."""
    display_social_account(choice)
