"""
Module 4: IP OSINT
- IP -> ASN
- ISP / Organization
- Approximate geographic information such as Country / City
- Reverse DNS (PTR record / Hostname)
- Open service & port information (standard port probing)
"""

import socket
import requests
from concurrent.futures import ThreadPoolExecutor

from utils.colors import (
    c, status_msg, section_header, key_val,
    NEON_PURPLE, NEON_PINK, CYAN, GREEN, YELLOW, RED, WHITE, GRAY, RESET, BOLD
)

COMMON_SERVICES = {
    21: "FTP",
    22: "SSH",
    25: "SMTP",
    53: "DNS",
    80: "HTTP",
    110: "POP3",
    143: "IMAP",
    443: "HTTPS",
    465: "SMTPS",
    587: "SMTP (Submission)",
    993: "IMAPS",
    995: "POP3S",
    3306: "MySQL",
    5432: "PostgreSQL",
    8080: "HTTP-Proxy/Alt",
    8443: "HTTPS-Alt"
}

def check_port(ip: str, port: int, timeout: float = 0.6) -> tuple:
    """Checks whether a specific port is open."""
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(timeout)
        result = sock.connect_ex((ip, port))
        sock.close()
        if result == 0:
            return port, True
    except Exception:
        pass
    return port, False

def get_ip_info(target: str) -> dict:
    """Collects all IP OSINT data."""
    target = target.strip()
    data = {
        "query": target,
        "ip": "",
        "reverse_dns": "",
        "geo": {},
        "open_services": []
    }

    # IP resolution
    try:
        resolved_ip = socket.gethostbyname(target)
        data["ip"] = resolved_ip
    except Exception as e:
        data["error"] = f"Could not resolve IP: {e}"
        return data

    # Reverse DNS
    try:
        host, _, _ = socket.gethostbyaddr(data["ip"])
        data["reverse_dns"] = host
    except Exception:
        data["reverse_dns"] = "PTR Record Not Found"

    # Geographic and ASN Information (ip-api.com)
    try:
        fields = "status,message,country,countryCode,regionName,city,zip,lat,lon,timezone,isp,org,as,query"
        r = requests.get(f"http://ip-api.com/json/{data['ip']}?fields={fields}", timeout=5)
        if r.status_code == 200:
            data["geo"] = r.json()
    except Exception:
        data["geo"] = {}

    # Open Services / Port Check (Fast Multi-threading)
    open_ports = []
    with ThreadPoolExecutor(max_workers=10) as executor:
        futures = [executor.submit(check_port, data["ip"], port) for port in COMMON_SERVICES.keys()]
        for f in futures:
            p, is_open = f.result()
            if is_open:
                open_ports.append((p, COMMON_SERVICES.get(p, "Unknown Service")))
    data["open_services"] = sorted(open_ports, key=lambda x: x[0])

    return data

def print_ip_osint(data: dict):
    """Prints IP OSINT results."""
    if "error" in data:
        status_msg("!", data["error"], RED)
        return

    ip = data.get("ip")
    geo = data.get("geo", {})

    print(f"\n{BOLD}{NEON_PURPLE}[◈] Target IP:{RESET} {GREEN}{ip}{RESET}")
    if data.get("reverse_dns"):
        key_val("Reverse DNS (Hostname)", data["reverse_dns"])

    # ASN / ISP
    print(f"\n{BOLD}{NEON_PURPLE}[1] ASN, ISP, and Organization:{RESET}")
    key_val("ASN", geo.get("as", "Unknown"))
    key_val("ISP (Internet Service Provider)", geo.get("isp", "Unknown"))
    key_val("Organization", geo.get("org", "Unknown"))

    # Geographic Information
    print(f"\n{BOLD}{NEON_PURPLE}[2] Geographic Location Information:{RESET}")
    country = f"{geo.get('country', '-')} ({geo.get('countryCode', '-')})"
    location = f"{geo.get('city', '-')}, {geo.get('regionName', '-')}"
    coords = f"{geo.get('lat', '-')}, {geo.get('lon', '-')}"
    key_val("Country", country)
    key_val("City / Region", location)
    key_val("Postal Code", geo.get("zip", "-"))
    key_val("Approximate Coordinates", coords)
    key_val("Timezone", geo.get("timezone", "-"))

    # Open Services
    print(f"\n{BOLD}{NEON_PURPLE}[3] Detected Standard Open Services:{RESET}")
    open_ports = data.get("open_services", [])
    if open_ports:
        for port, service in open_ports:
            print(f"  {GREEN}[✓] Port {port:<5}{RESET} -> {WHITE}{service}{RESET}")
    else:
        print(f"  {GRAY}[-] Standard service ports are closed or filtered.{RESET}")

def run_ip_osint():
    section_header("4. IP OSINT")
    target = input(f"{BOLD}{NEON_PURPLE}[>] IP or Hostname to analyze (e.g. 8.8.8.8):{RESET} ").strip()
    if not target:
        status_msg("!", "Target cannot be empty.", RED)
        input(f"\n{GRAY}Press Enter to continue...{RESET}")
        return

    status_msg("*", f"Scanning ASN, ISP, geographic location, and services for '{target}'...", CYAN)
    data = get_ip_info(target)
    print_ip_osint(data)
    input(f"\n{NEON_PURPLE}[⏎] Press Enter to return to main menu...{RESET}")
