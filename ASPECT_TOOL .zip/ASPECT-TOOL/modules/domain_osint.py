"""
Module 3: Domain OSINT
- WHOIS information (Registrar, creation, expiration, NS)
- DNS records (A, AAAA, MX, NS, TXT, CNAME)
- IP address resolution
- ASN / Hosting and organization information
- Subdomain discovery (crt.sh Certificate Transparency - 100% legal & public)
- HTTP/HTTPS protocol status information
"""

import socket
import json
import requests
import dns.resolver
import whois
from urllib.parse import urlparse

from utils.colors import (
    c, status_msg, section_header, key_val,
    NEON_PURPLE, NEON_PINK, CYAN, GREEN, YELLOW, RED, WHITE, GRAY, RESET, BOLD
)

def clean_domain(target: str) -> str:
    """Cleans URL or domain input."""
    target = target.strip()
    if target.startswith("http://") or target.startswith("https://"):
        parsed = urlparse(target)
        return parsed.netloc.split(":")[0]
    return target.split("/")[0].split(":")[0]

def get_domain_info(domain: str) -> dict:
    """Collects and returns all domain OSINT data."""
    domain = clean_domain(domain)
    data = {
        "domain": domain,
        "ips": [],
        "whois": {},
        "dns": {},
        "asn_info": {},
        "subdomains": [],
        "http_info": {}
    }

    # 1. IP Addresses
    try:
        _, _, ip_list = socket.gethostbyname_ex(domain)
        data["ips"] = ip_list
    except Exception:
        data["ips"] = []

    # 2. ASN / Hosting (Via primary IP)
    if data["ips"]:
        primary_ip = data["ips"][0]
        try:
            r = requests.get(f"http://ip-api.com/json/{primary_ip}?fields=status,country,regionName,city,isp,org,as,query", timeout=5)
            if r.status_code == 200:
                data["asn_info"] = r.json()
        except Exception:
            pass

    # 3. DNS Records
    record_types = ['A', 'AAAA', 'MX', 'NS', 'TXT', 'CNAME', 'SOA']
    resolver = dns.resolver.Resolver()
    resolver.timeout = 3
    resolver.lifetime = 3

    for r_type in record_types:
        try:
            answers = resolver.resolve(domain, r_type)
            records = []
            for rdata in answers:
                if r_type == 'TXT':
                    records.append("".join([s.decode('utf-8', errors='ignore') if isinstance(s, bytes) else str(s) for s in rdata.strings]))
                elif r_type == 'MX':
                    records.append(f"{rdata.exchange} (Priority: {rdata.preference})")
                else:
                    records.append(str(rdata))
            data["dns"][r_type] = records
        except Exception:
            data["dns"][r_type] = []

    # 4. WHOIS
    try:
        w = whois.whois(domain)
        data["whois"] = {
            "registrar": w.registrar,
            "creation_date": str(w.creation_date),
            "expiration_date": str(w.expiration_date),
            "updated_date": str(w.updated_date),
            "name_servers": w.name_servers if isinstance(w.name_servers, list) else [w.name_servers],
            "status": w.status if isinstance(w.status, list) else [w.status],
            "emails": w.emails if isinstance(w.emails, list) else [w.emails]
        }
    except Exception:
        # RDAP Fallback
        try:
            rd = requests.get(f"https://rdap.org/domain/{domain}", timeout=5)
            if rd.status_code == 200:
                r_json = rd.json()
                data["whois"] = {
                    "registrar": r_json.get("entities", [{}])[0].get("vcardArray", [None, []])[1][1][3] if r_json.get("entities") else "Unknown",
                    "status": r_json.get("status", []),
                    "name_servers": [ns.get("ldhName") for ns in r_json.get("nameservers", [])]
                }
        except Exception:
            data["whois"] = {"error": "WHOIS information could not be retrieved or is restricted."}

    # 5. Subdomain Discovery (crt.sh Certificate Transparency)
    try:
        url = f"https://crt.sh/?q=%.{domain}&output=json"
        crtr = requests.get(url, headers={"User-Agent": "Mozilla/5.0"}, timeout=10)
        if crtr.status_code == 200:
            subs = set()
            for entry in crtr.json():
                name_value = entry.get("name_value", "")
                for sub in name_value.split("\n"):
                    sub = sub.strip().lower()
                    if "*" not in sub and sub.endswith(domain):
                        subs.add(sub)
            data["subdomains"] = sorted(list(subs))
    except Exception:
        data["subdomains"] = []

    # 6. HTTP/HTTPS Check
    for proto in ["https", "http"]:
        try:
            resp = requests.get(f"{proto}://{domain}", timeout=5, allow_redirects=True, headers={"User-Agent": "Mozilla/5.0"})
            data["http_info"][proto] = {
                "status_code": resp.status_code,
                "server": resp.headers.get("Server", "Unspecified"),
                "final_url": resp.url,
                "redirects": [r.url for r in resp.history]
            }
        except Exception as e:
            data["http_info"][proto] = {"error": str(e)}

    return data

def print_domain_osint(data: dict):
    """Prints collected domain OSINT data formatted to the screen."""
    domain = data["domain"]
    print(f"\n{BOLD}{NEON_PURPLE}[◈] Domain:{RESET} {WHITE}{domain}{RESET}")
    
    # IPs
    ips = data.get("ips", [])
    print(f"  {NEON_PINK}• IP Addresses:{RESET} {GREEN}{', '.join(ips) if ips else 'Not Found'}{RESET}")

    # ASN / Hosting
    asn = data.get("asn_info", {})
    if asn and asn.get("status") == "success":
        print(f"\n{BOLD}{NEON_PURPLE}[1] ASN & Hosting Information:{RESET}")
        key_val("ASN", asn.get("as", "-"))
        key_val("ISP (Provider)", asn.get("isp", "-"))
        key_val("Organization", asn.get("org", "-"))
        key_val("Location", f"{asn.get('city', '-')}, {asn.get('country', '-')}")

    # WHOIS
    wh = data.get("whois", {})
    print(f"\n{BOLD}{NEON_PURPLE}[2] WHOIS Information:{RESET}")
    if "error" in wh:
        print(f"  {YELLOW}{wh['error']}{RESET}")
    else:
        key_val("Registrar", str(wh.get("registrar", "-")))
        key_val("Creation Date", str(wh.get("creation_date", "-")))
        key_val("Expiration Date", str(wh.get("expiration_date", "-")))
        ns = wh.get("name_servers", [])
        if ns:
            ns_str = ", ".join([str(x) for x in ns if x])
            key_val("Name Servers", ns_str[:80])

    # DNS Records
    print(f"\n{BOLD}{NEON_PURPLE}[3] DNS Records:{RESET}")
    dns_records = data.get("dns", {})
    for r_type, records in dns_records.items():
        if records:
            print(f"  {CYAN}• {r_type:<5}:{RESET} {WHITE}{', '.join(records[:4])}{' ...' if len(records) > 4 else ''}{RESET}")

    # Subdomains
    subs = data.get("subdomains", [])
    print(f"\n{BOLD}{NEON_PURPLE}[4] Subdomain Discovery (crt.sh):{RESET}")
    if subs:
        print(f"  {GREEN}[✓] Total of {len(subs)} unique subdomains found:{RESET}")
        for s in subs[:15]:
            print(f"    {WHITE}• {s}{RESET}")
        if len(subs) > 15:
            print(f"    {GRAY}... and {len(subs) - 15} more{RESET}")
    else:
        print(f"  {YELLOW}[-] No public certificate record found or query timed out.{RESET}")

    # HTTP / HTTPS
    print(f"\n{BOLD}{NEON_PURPLE}[5] HTTP / HTTPS Status:{RESET}")
    http_data = data.get("http_info", {})
    for proto, info in http_data.items():
        if "error" in info:
            print(f"  {YELLOW}• {proto.upper()}:{RESET} {GRAY}Connection error{RESET}")
        else:
            status_code = info.get("status_code")
            server = info.get("server")
            print(f"  {GREEN}• {proto.upper()}:{RESET} Status: {WHITE}{status_code}{RESET} | Server: {CYAN}{server}{RESET}")

def run_domain_osint():
    section_header("3. DOMAIN OSINT")
    target = input(f"{BOLD}{NEON_PURPLE}[>] Domain to analyze (e.g., example.com):{RESET} ").strip()
    if not target:
        status_msg("!", "Domain cannot be empty.", RED)
        input(f"\n{GRAY}Press Enter to continue...{RESET}")
        return

    status_msg("*", f"Querying WHOIS, DNS, IP, ASN and subdomains for '{target}'...", CYAN)
    data = get_domain_info(target)
    print_domain_osint(data)
    input(f"\n{NEON_PURPLE}[⏎] Press Enter to return to main menu...{RESET}")
