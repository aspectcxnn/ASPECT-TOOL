"""
Module 8: Comprehensive OSINT from URL
When the user enters a URL:
- Website analysis (Headers, SSL, Technologies, Robots, Sitemap, Redirects)
- Domain OSINT (WHOIS, DNS, IP, ASN/Hosting, Subdomains)
- IP OSINT (ASN, ISP, Geolocation, Reverse DNS, Services)
combines these steps sequentially into a single report.
Afterwards:
- Pressing 0 saves it to the Desktop as a TXT file.
- Pressing 1 returns to the main menu.
"""

import os
import re
import datetime
from urllib.parse import urlparse

from modules.domain_osint import get_domain_info, print_domain_osint
from modules.ip_osint import get_ip_info, print_ip_osint
from modules.web_analysis import analyze_website, print_web_analysis
from utils.colors import (
    c, status_msg, section_header, key_val,
    NEON_PURPLE, DARK_PURPLE, NEON_PINK, CYAN, GREEN, YELLOW, RED, WHITE, GRAY, RESET, BOLD
)

def build_txt_report(target_url: str, web_data: dict, domain_data: dict, ip_data: dict) -> str:
    """Converts report data into a clean plain text (TXT) file."""
    lines = []
    lines.append("=" * 70)
    lines.append("            ASPECT OSINT TOOL - COMPREHENSIVE TARGET REPORT")
    lines.append(f"  Date / Time   : {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    lines.append(f"  Target URL    : {target_url}")
    lines.append("  License / Scope: Public Data Sources")
    lines.append("=" * 70)
    lines.append("")

    # 1. WEB ANALYSIS
    lines.append("--- [1] WEBSITE ANALYSIS & HTTP HEADERS ---")
    lines.append(f"Final URL: {web_data.get('final_url', '-')}")
    lines.append(f"HTTP Status Code: {web_data.get('status_code', '-')}")
    
    chain = web_data.get("redirect_chain", [])
    if chain:
        lines.append("Redirect Chain:")
        for idx, hop in enumerate(chain, 1):
            lines.append(f"  Hop {idx}: [{hop['status_code']}] {hop['url']} -> {hop.get('location')}")
    
    # SSL
    ssl_info = web_data.get("ssl_cert", {})
    lines.append("\nSSL / TLS Certificate:")
    if "error" in ssl_info:
        lines.append(f"  Error: {ssl_info['error']}")
    else:
        lines.append(f"  Certificate Subject (CN): {ssl_info.get('common_name')}")
        lines.append(f"  Certificate Issuer (CA): {ssl_info.get('issuer_org')} ({ssl_info.get('issuer_cn')})")
        lines.append(f"  Remaining Days: {ssl_info.get('days_left')} days")
        lines.append(f"  TLS Version / Cipher: {ssl_info.get('tls_version')} / {ssl_info.get('cipher')}")
        san_list = ssl_info.get("san", [])
        if san_list:
            lines.append(f"  Alternative Names (SAN): {', '.join(san_list)}")

    # Security Headers
    lines.append("\nSecurity Headers Check:")
    for h_name, h_info in web_data.get("security_headers", {}).items():
        status = "PRESENT" if h_info["found"] else "MISSING"
        lines.append(f"  [{status:<7}] {h_name:<28} - {h_info['desc']}")

    # Technologies
    lines.append("\nDetected Technologies:")
    techs = web_data.get("technologies", [])
    if techs:
        for t in techs:
            lines.append(f"  - {t}")
    else:
        lines.append("  - No significant traces found.")

    # Robots & Sitemap
    lines.append("\nRobots.txt & Sitemap:")
    rb = web_data.get("robots_txt", {})
    lines.append(f"  Robots.txt: {'Present (' + str(rb.get('disallow_count')) + ' rules)' if rb.get('found') else 'Not Found'}")
    sm = web_data.get("sitemap_xml", {})
    lines.append(f"  Sitemap: {'Present (Approx. ' + str(sm.get('url_count')) + ' URLs)' if sm.get('found') else 'Not Found'}")
    lines.append("")

    # 2. DOMAIN OSINT
    lines.append("--- [2] DOMAIN OSINT INFORMATION ---")
    lines.append(f"Domain: {domain_data.get('domain', '-')}")
    lines.append(f"Resolved IP Addresses: {', '.join(domain_data.get('ips', []))}")
    
    wh = domain_data.get("whois", {})
    lines.append("\nWHOIS Information:")
    if "error" in wh:
        lines.append(f"  {wh['error']}")
    else:
        lines.append(f"  Registrar: {wh.get('registrar')}")
        lines.append(f"  Creation Date: {wh.get('creation_date')}")
        lines.append(f"  Expiration Date: {wh.get('expiration_date')}")
        ns = wh.get("name_servers", [])
        if ns:
            lines.append(f"  Name Servers: {', '.join([str(x) for x in ns if x])}")

    # DNS
    lines.append("\nDNS Records:")
    for r_type, records in domain_data.get("dns", {}).items():
        if records:
            lines.append(f"  {r_type:<6}: {', '.join(records)}")

    # Subdomains
    subs = domain_data.get("subdomains", [])
    lines.append(f"\nSubdomains (crt.sh - Total {len(subs)}):")
    for s in subs:
        lines.append(f"  - {s}")
    lines.append("")

    # 3. IP OSINT
    lines.append("--- [3] IP & HOSTING OSINT INFORMATION ---")
    geo = ip_data.get("geo", {})
    lines.append(f"IP: {ip_data.get('ip', '-')}")
    lines.append(f"Reverse DNS: {ip_data.get('reverse_dns', '-')}")
    lines.append(f"ASN: {geo.get('as', '-')}")
    lines.append(f"ISP / Organization: {geo.get('isp', '-')} / {geo.get('org', '-')}")
    lines.append(f"Location: {geo.get('city', '-')}, {geo.get('regionName', '-')}, {geo.get('country', '-')}")
    lines.append(f"Coordinates: {geo.get('lat', '-')}, {geo.get('lon', '-')}")
    lines.append(f"Timezone: {geo.get('timezone', '-')}")

    # Open Services
    lines.append("\nOpen Services / Ports:")
    open_ports = ip_data.get("open_services", [])
    if open_ports:
        for p, s in open_ports:
            lines.append(f"  Port {p:<5} -> {s}")
    else:
        lines.append("  No standard open services detected.")

    lines.append("\n" + "=" * 70)
    lines.append("                   END OF REPORT (ASPECT TOOL)")
    lines.append("=" * 70)

    return "\n".join(lines)

def run_url_comprehensive():
    section_header("8. COMPREHENSIVE URL OSINT")
    target = input(f"{BOLD}{NEON_PURPLE}[>] Target URL to analyze (e.g. https://example.com):{RESET} ").strip()
    if not target:
        status_msg("!", "URL cannot be empty.", RED)
        input(f"\n{GRAY}Press Enter to continue...{RESET}")
        return

    parsed = urlparse(target if "://" in target else "https://" + target)
    hostname = parsed.netloc.split(":")[0]

    print()
    status_msg("1/3", f"Scanning website and security parameters...", CYAN)
    web_data = analyze_website(target)
    print_web_analysis(web_data)

    print()
    status_msg("2/3", f"Scanning domain, WHOIS, DNS and crt.sh subdomains...", CYAN)
    domain_data = get_domain_info(hostname)
    print_domain_osint(domain_data)

    print()
    status_msg("3/3", f"Scanning IP geolocation, ASN, ISP and open ports...", CYAN)
    ip_target = domain_data.get("ips", [hostname])[0] if domain_data.get("ips") else hostname
    ip_data = get_ip_info(ip_target)
    print_ip_osint(ip_data)

    print(f"\n{GREEN}{BOLD}[✓] Comprehensive OSINT Analysis Completed!{RESET}")
    print(f"{DARK_PURPLE}{'━' * 60}{RESET}")
    print(f"  {BOLD}{NEON_PURPLE}<<0>>{RESET} {WHITE}[Save as TXT File to Desktop]{RESET}")
    print(f"  {BOLD}{NEON_PURPLE}<<1>>{RESET} {WHITE}[Exit and Return to Main Menu]{RESET}")
    print(f"{DARK_PURPLE}{'━' * 60}{RESET}")

    while True:
        action = input(f"\n{BOLD}{NEON_PINK}[>] Your choice (0 / 1):{RESET} ").strip()
        if action == "0":
            # Save TXT to Desktop
            desktop_dir = "/home/aspect/Masaüstü"
            if not os.path.exists(desktop_dir):
                desktop_dir = os.path.expanduser("~/Desktop")
            
            clean_host = re.sub(r'[^a-zA-Z0-9_\-]', '_', hostname)
            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"ASPECT_REPORT_{clean_host}_{timestamp}.txt"
            filepath = os.path.join(desktop_dir, filename)

            report_content = build_txt_report(target, web_data, domain_data, ip_data)
            try:
                with open(filepath, "w", encoding="utf-8") as f:
                    f.write(report_content)
                print(f"\n{GREEN}{BOLD}[✓] Report successfully saved to Desktop!{RESET}")
                print(f"  {NEON_PINK}File Path:{RESET} {WHITE}{filepath}{RESET}")
            except Exception as e:
                print(f"\n{RED}[!] An error occurred while saving the file: {e}{RESET}")
            
            input(f"\n{NEON_PURPLE}[⏎] Press Enter to return to main menu...{RESET}")
            break
        elif action == "1":
            print(f"{CYAN}Returning to main menu...{RESET}")
            break
        else:
            print(f"{RED}Invalid choice! Please press 0 or 1.{RESET}")
