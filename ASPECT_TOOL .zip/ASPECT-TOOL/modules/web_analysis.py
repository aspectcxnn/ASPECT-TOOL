"""
Module 7: Website Analysis
- HTTP Headers (Security headers analysis)
- SSL/TLS Certificate details (Issuer, remaining days, SANs, cipher/encryption)
- Technology detection (Server, Framework, CMS, JavaScript libraries)
- Robots.txt inspection
- Sitemap.xml check
- DNS records
- Redirect chain
"""

import socket
import ssl
import datetime
from urllib.parse import urlparse
import urllib3
import requests
from bs4 import BeautifulSoup
import dns.resolver

# Suppress InsecureRequest warnings
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

from utils.colors import (
    c, status_msg, section_header, key_val,
    NEON_PURPLE, NEON_PINK, CYAN, GREEN, YELLOW, RED, WHITE, GRAY, RESET, BOLD
)

SECURITY_HEADERS = [
    ("Strict-Transport-Security", "HSTS (Enforce HTTPS)"),
    ("Content-Security-Policy", "CSP (XSS and Injection Protection)"),
    ("X-Frame-Options", "Clickjacking Protection"),
    ("X-Content-Type-Options", "MIME Sniffing Protection"),
    ("Referrer-Policy", "Referrer Privacy Policy"),
    ("Permissions-Policy", "Browser Permissions Management")
]

def analyze_website(target: str) -> dict:
    """Performs website analysis for the given URL or domain."""
    if not target.startswith("http://") and not target.startswith("https://"):
        target_url = "https://" + target
    else:
        target_url = target

    parsed = urlparse(target_url)
    hostname = parsed.netloc.split(":")[0]

    data = {
        "target_url": target_url,
        "hostname": hostname,
        "redirect_chain": [],
        "final_url": "",
        "status_code": 0,
        "headers": {},
        "security_headers": {},
        "ssl_cert": {},
        "technologies": [],
        "robots_txt": {},
        "sitemap_xml": {},
        "dns": {}
    }

    # 1. HTTP Request and Redirect Chain
    try:
        session = requests.Session()
        session.headers.update({
            "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        })
        resp = session.get(target_url, timeout=10, allow_redirects=True, verify=False)
        data["status_code"] = resp.status_code
        data["final_url"] = resp.url
        data["headers"] = dict(resp.headers)

        for hop in resp.history:
            data["redirect_chain"].append({
                "status_code": hop.status_code,
                "url": hop.url,
                "location": hop.headers.get("Location")
            })

        html_text = resp.text
    except Exception as e:
        data["error"] = f"Could not connect to the site: {e}"
        return data

    # 2. Security Headers Analysis
    headers_lower = {k.lower(): v for k, v in data["headers"].items()}
    for h_name, desc in SECURITY_HEADERS:
        found = h_name.lower() in headers_lower
        data["security_headers"][h_name] = {
            "found": found,
            "value": headers_lower.get(h_name.lower(), ""),
            "desc": desc
        }

    # 3. SSL/TLS Certificate Analysis
    try:
        ctx = ssl.create_default_context()
        with socket.create_connection((hostname, 443), timeout=5) as sock:
            with ctx.wrap_socket(sock, server_hostname=hostname) as ssock:
                cert = ssock.getpeercert()
                cipher = ssock.cipher()
                tls_version = ssock.version()
                
                not_after = cert.get('notAfter')
                not_before = cert.get('notBefore')
                
                issuer_dict = dict(x[0] for x in cert.get('issuer', []))
                subject_dict = dict(x[0] for x in cert.get('subject', []))
                
                # Calculate remaining days
                days_left = None
                if not_after:
                    exp_date = datetime.datetime.strptime(not_after, "%b %d %H:%M:%S %Y %Z")
                    now_utc = datetime.datetime.now(datetime.timezone.utc).replace(tzinfo=None)
                    days_left = (exp_date - now_utc).days

                data["ssl_cert"] = {
                    "common_name": subject_dict.get('commonName', hostname),
                    "issuer_org": issuer_dict.get('organizationName', 'Unknown'),
                    "issuer_cn": issuer_dict.get('commonName', 'Unknown'),
                    "not_before": not_before,
                    "not_after": not_after,
                    "days_left": days_left,
                    "tls_version": tls_version,
                    "cipher": cipher[0] if cipher else "Unknown",
                    "san": [x[1] for x in cert.get('subjectAltName', []) if x[0] == 'DNS']
                }
    except Exception as e:
        data["ssl_cert"] = {"error": f"SSL information could not be retrieved ({e})"}

    # 4. Technology Detection
    techs = []
    server_h = data["headers"].get("Server")
    if server_h:
        techs.append(f"Web Server: {server_h}")
    powered_by = data["headers"].get("X-Powered-By")
    if powered_by:
        techs.append(f"Infrastructure (X-Powered-By): {powered_by}")

    # HTML analysis
    soup = BeautifulSoup(html_text, "html.parser")
    generator_meta = soup.find("meta", attrs={"name": "generator"})
    if generator_meta and generator_meta.get("content"):
        techs.append(f"Generator / CMS: {generator_meta.get('content')}")

    html_lower = html_text.lower()
    if "wp-content" in html_lower or "wp-includes" in html_lower:
        techs.append("CMS: WordPress")
    if "drupal.js" in html_lower or "drupalSettings" in html_lower:
        techs.append("CMS: Drupal")
    if "joomla" in html_lower:
        techs.append("CMS: Joomla")
    if "__next" in html_lower or "_next/static" in html_lower:
        techs.append("Framework: Next.js (React)")
    if "nuxt" in html_lower or "_nuxt" in html_lower:
        techs.append("Framework: Nuxt.js (Vue)")
    if "cloudflare" in headers_lower.get("server", "").lower() or "cf-ray" in headers_lower:
        techs.append("CDN/WAF: Cloudflare")
    if "bootstrap" in html_lower:
        techs.append("UI: Bootstrap")
    if "tailwind" in html_lower:
        techs.append("UI: Tailwind CSS")
    if "jquery" in html_lower:
        techs.append("Library: jQuery")

    data["technologies"] = list(set(techs))

    # 5. Robots.txt
    try:
        robots_url = f"{parsed.scheme}://{hostname}/robots.txt"
        rb_resp = requests.get(robots_url, timeout=5, headers=session.headers, verify=False)
        if rb_resp.status_code == 200:
            lines = [l.strip() for l in rb_resp.text.split("\n") if l.strip() and not l.strip().startswith("#")]
            disallows = [l.split(":", 1)[1].strip() for l in lines if l.lower().startswith("disallow:")]
            data["robots_txt"] = {
                "found": True,
                "url": robots_url,
                "disallow_count": len(disallows),
                "samples": disallows[:8]
            }
        else:
            data["robots_txt"] = {"found": False, "status": rb_resp.status_code}
    except Exception:
        data["robots_txt"] = {"found": False}

    # 6. Sitemap.xml
    try:
        sitemap_url = f"{parsed.scheme}://{hostname}/sitemap.xml"
        sm_resp = requests.get(sitemap_url, timeout=5, headers=session.headers, verify=False)
        if sm_resp.status_code == 200:
            url_count = sm_resp.text.count("<loc>")
            data["sitemap_xml"] = {
                "found": True,
                "url": sitemap_url,
                "url_count": url_count
            }
        else:
            data["sitemap_xml"] = {"found": False, "status": sm_resp.status_code}
    except Exception:
        data["sitemap_xml"] = {"found": False}

    # 7. DNS Records (For Web Hostname)
    try:
        res = dns.resolver.Resolver()
        res.timeout = 3
        a_records = [str(r) for r in res.resolve(hostname, 'A')]
        data["dns"]["A"] = a_records
    except Exception:
        data["dns"]["A"] = []

    return data

def print_web_analysis(data: dict):
    """Prints website analysis results."""
    if "error" in data:
        status_msg("!", data["error"], RED)
        return

    print(f"\n{BOLD}{NEON_PURPLE}[◈] Target URL:{RESET} {WHITE}{data['target_url']}{RESET}")
    print(f"  {NEON_PINK}• Final URL:{RESET} {GREEN}{data['final_url']}{RESET} (HTTP {data['status_code']})")

    # Redirect Chain
    chain = data.get("redirect_chain", [])
    if chain:
        print(f"\n{BOLD}{NEON_PURPLE}[1] Redirect Chain:{RESET}")
        for idx, hop in enumerate(chain, 1):
            print(f"  {CYAN}Hop {idx}:{RESET} [{YELLOW}HTTP {hop['status_code']}{RESET}] {WHITE}{hop['url']}{RESET} -> {GRAY}{hop['location']}{RESET}")
    else:
        print(f"\n{BOLD}{NEON_PURPLE}[1] Redirect Chain:{RESET} {GRAY}Direct connection (No redirects).{RESET}")

    # SSL / TLS
    print(f"\n{BOLD}{NEON_PURPLE}[2] SSL / TLS Certificate Details:{RESET}")
    ssl_info = data.get("ssl_cert", {})
    if "error" in ssl_info:
        print(f"  {YELLOW}{ssl_info['error']}{RESET}")
    else:
        key_val("Certificate Subject (CN)", ssl_info.get("common_name", "-"))
        key_val("Certificate Issuer (CA)", f"{ssl_info.get('issuer_org', '-')} ({ssl_info.get('issuer_cn', '-')})")
        days = ssl_info.get("days_left")
        days_color = GREEN if days and days > 30 else RED
        key_val("Remaining Validity", f"{days_color}{days} days{RESET}" if days is not None else "-")
        key_val("Protocol / Cipher", f"{ssl_info.get('tls_version', '-')} / {ssl_info.get('cipher', '-')}")
        san_list = ssl_info.get("san", [])
        if san_list:
            key_val("Subject Alternative Names (SAN)", ", ".join(san_list[:4]) + ("..." if len(san_list) > 4 else ""))

    # Security Headers
    print(f"\n{BOLD}{NEON_PURPLE}[3] HTTP Security Headers:{RESET}")
    for h_name, h_info in data.get("security_headers", {}).items():
        if h_info["found"]:
            print(f"  {GREEN}[✓] {h_name:<28}{RESET} -> {WHITE}Present ({h_info['desc']}){RESET}")
        else:
            print(f"  {RED}[✗] {h_name:<28}{RESET} -> {GRAY}Missing ({h_info['desc']}){RESET}")

    # Technology Detection
    print(f"\n{BOLD}{NEON_PURPLE}[4] Technology and Infrastructure Detection:{RESET}")
    techs = data.get("technologies", [])
    if techs:
        for t in techs:
            print(f"  {CYAN}◈ {t}{RESET}")
    else:
        print(f"  {GRAY}[-] No distinct technology or CMS trace found.{RESET}")

    # Robots.txt & Sitemap
    print(f"\n{BOLD}{NEON_PURPLE}[5] Robots.txt and Sitemap Analysis:{RESET}")
    rb = data.get("robots_txt", {})
    if rb.get("found"):
        print(f"  {GREEN}[✓] Robots.txt present:{RESET} {WHITE}{rb['url']}{RESET} ({rb['disallow_count']} restricted path(s))")
        if rb.get("samples"):
            print(f"    {GRAY}Sample restricted paths: {', '.join(rb['samples'][:5])}{RESET}")
    else:
        print(f"  {GRAY}[-] Robots.txt not found.{RESET}")

    sm = data.get("sitemap_xml", {})
    if sm.get("found"):
        print(f"  {GREEN}[✓] Sitemap.xml present:{RESET} {WHITE}{sm['url']}{RESET} (~{sm['url_count']} URLs)")
    else:
        print(f"  {GRAY}[-] Sitemap.xml not found.{RESET}")

def run_web_analysis():
    section_header("7. WEBSITE ANALYSIS")
    target = input(f"{BOLD}{NEON_PURPLE}[>] Target Website URL to analyze (e.g., https://example.com):{RESET} ").strip()
    if not target:
        status_msg("!", "URL cannot be empty.", RED)
        input(f"\n{GRAY}Press Enter to continue...{RESET}")
        return

    status_msg("*", f"Scanning HTTP headers, SSL, technology, and robots.txt for '{target}'...", CYAN)
    data = analyze_website(target)
    print_web_analysis(data)
    input(f"\n{NEON_PURPLE}[⏎] Press Enter to return to main menu...{RESET}")
