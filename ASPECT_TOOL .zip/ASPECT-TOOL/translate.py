import os, glob

replacements = {
    "Module 5: Phone Number OSINT": "Module 5: Phone Number OSINT",
    "Phone Number:": "Phone Number:",
    "Number cannot be empty.": "Number cannot be empty.",
    "Enter number in international format": "Enter number in international format",
    "Press Enter to continue...": "Press Enter to continue...",
    "Number could not be parsed:": "Number could not be parsed:",
    "Press Enter to return to main menu...": "Press Enter to return to main menu...",
    "Valid and Active Format": "Valid and Active Format",
    "Invalid Number": "Invalid Number",
    "Possible Number": "Possible Number",
    "Not Possible": "Not Possible",
    "Validity Status": "Validity Status",
    "Format Check": "Format Check",
    "E.164 Format": "E.164 Format",
    "International Format": "International Format",
    "National Format": "National Format",
    "Geographical and Country Info:": "Geographical and Country Info:",
    "Country Code": "Country Code",
    "Country / Location": "Country / Location",
    "Carrier and Line Type:": "Carrier and Line Type:",
    "Line Type": "Line Type",
    "Carrier (Network)": "Carrier (Network)",
    "Public Web Search Dorks:": "Public Web Search Dorks:",
    "Open search link in browser? (y/n):": "Open search link in browser? (y/n):",
    "Search opened in browser.": "Search opened in browser.",
    "Unknown Type": "Unknown Type",
    "Toll-Free Line": "Toll-Free Line",
    "Premium Rate Line": "Premium Rate Line",
    "Shared Cost Line": "Shared Cost Line",
    "Internet Phone (VoIP)": "Internet Phone (VoIP)",
    "Personal Number": "Personal Number",
    "Pager": "Pager",
    "Universal Access Number (UAN)": "Universal Access Number (UAN)",
    "Carrier Not Found in Database / Prepaid": "Carrier Not Found in Database / Prepaid",
    "Target domain (e.g. example.com): ": "Target domain (e.g. example.com): ",
    "Please enter a valid domain name.": "Please enter a valid domain name.",
    "Domain could not be resolved or is not active.": "Domain could not be resolved or is not active.",
    "Domain OSINT Results:": "Domain OSINT Results:",
    "Registered Company/Person": "Registered Company/Person",
    "Registrar": "Registrar",
    "Creation Date": "Creation Date",
    "Expiration Date": "Expiration Date",
    "Updated Date": "Updated Date",
    "Name Servers (NS)": "Name Servers (NS)",
    "Not Found or Hidden": "Not Found or Hidden",
    "IP Resolution (A Record)": "IP Resolution (A Record)",
    "IP Address": "IP Address",
    "Host Not Found": "Host Not Found",
    "Not Found": "Not Found",
    "Error:": "Error:",
    "Target username: ": "Target username: ",
    "Username OSINT process starting...": "Username OSINT process starting...",
    "Target URL/Domain (e.g. https://example.com): ": "Target URL/Domain (e.g. https://example.com): ",
    "Target IP address: ": "Target IP address: ",
    "Target email address: ": "Target email address: ",
    "A valid": "A valid",
    "enter.": "enter.",
    "Platform Selection (1-8): ": "Platform Selection (1-8): ",
    "Saved to Desktop:": "Saved to Desktop:",
    "Process completed.": "Process completed.",
    "IP Information": "IP Information",
    "City": "City",
    "Region": "Region",
    "Country": "Country",
    "Location": "Location",
    "Organization": "Organization",
    "Postal Code": "Postal Code",
    "Timezone": "Timezone",
    "Server Response": "Server Response",
    "Active": "Active",
    "Closed": "Closed",
    "Open Ports": "Open Ports",
    "Closed/Filtreli Portlar": "Closed/Filtered Ports",
    "Process cancelled.": "Process cancelled.",
    "Dosya not found:": "File not found:",
    "File name to save": "File name to save",
    "Please enter an option:": "Please enter an option:",
    "Invalid choice!": "Invalid choice!",
    "Module starting...": "Module starting...",
    "Process continuing...": "Process continuing...",
    "Save results? (y/n):": "Save results? (y/n):",
    "Yes": "Yes",
    "No": "No",
    "All": "All",
    "Loading...": "Loading...",
    "Connection error:": "Connection error:",
    "Timeout:": "Timeout:",
    "An unexpected error occurred:": "An unexpected error occurred:",
    "Password": "Password",
    "Username": "Username",
    "Email": "Email",
    "Login Successful": "Login Successful",
    "Login Failed": "Login Failed",
    "Warning:": "Warning:",
    "Info:": "Info:",
    "Success:": "Success:",
    "Failed:": "Failed:",
    "Status": "Status",
    "Exiting...": "Exiting...",
    "Do you want to continue? (y/n): ": "Do you want to continue? (y/n): ",
    "Quit (q)": "Quit (q)",
    "Back (b)": "Back (b)",
    "Next (n)": "Next (n)"
}

for filepath in glob.glob("./**/*.py", recursive=True):
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    
    original_content = content
    for tr, en in replacements.items():
        content = content.replace(tr, en)
        content = content.replace(tr.lower(), en.lower())
        content = content.replace(tr.upper(), en.upper())
    
    if content != original_content:
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f"Updated: {filepath}")

for filepath in glob.glob("./**/*.html", recursive=True):
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    
    original_content = content
    for tr, en in replacements.items():
        content = content.replace(tr, en)
        
    if content != original_content:
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f"Updated: {filepath}")

