#!/usr/bin/env python3
"""
ASPECT - Ethical Open Source Intelligence (OSINT) Suite
Arch Linux / KDE Plasma Terminal Edition
Theme: Neon Purple / Cyberpunk
"""

import sys
import os

# Add script directory to python path
CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
if CURRENT_DIR not in sys.path:
    sys.path.insert(0, CURRENT_DIR)

from utils.banner import print_banner, print_menu, clear_screen
from utils.colors import (
    c, status_msg,
    NEON_PURPLE, NEON_PINK, CYAN, GREEN, YELLOW, RED, WHITE, GRAY, RESET, BOLD
)

from modules.username_osint import run_username_osint
from modules.email_osint import run_email_osint
from modules.domain_osint import run_domain_osint
from modules.ip_osint import run_ip_osint
from modules.phone_osint import run_phone_osint
from modules.github_osint import run_github_osint
import time
from modules.web_analysis import run_web_analysis
from modules.url_comprehensive import run_url_comprehensive
from modules.giftcard_generator import run_giftcard_generator
from modules.discord_suite import run_discord_suite

def main():
    current_page = 1
    while True:
        try:
            print_banner(current_page)
            print_menu(current_page)

            choice = input(f"{BOLD}{NEON_PURPLE}[>]{RESET} {BOLD}{WHITE}Your Choice:{RESET} ").strip().lower()

            # Page Navigation Controls
            if choice in ["n", "next"]:
                if current_page < 3:
                    current_page += 1
                else:
                    current_page = 1
                continue
            elif choice in ["b", "back"]:
                if current_page > 1:
                    current_page -= 1
                else:
                    current_page = 3
                continue
            elif choice in ["0", "exit", "quit", "q"]:
                clear_screen()
                print(f"\n{BOLD}{NEON_PURPLE}ASPECT Suite terminated. Goodbye!{RESET}\n")
                sys.exit(0)

            # Page 1: OSINT Tools
            if current_page == 1:
                if choice in ["1", "01"]:
                    run_username_osint()
                elif choice in ["2", "02"]:
                    run_email_osint()
                elif choice in ["3", "03"]:
                    run_domain_osint()
                elif choice in ["4", "04"]:
                    run_ip_osint()
                elif choice in ["5", "05"]:
                    run_phone_osint()
                elif choice in ["6", "06"]:
                    run_github_osint()
                elif choice in ["7", "07"]:
                    run_web_analysis()
                elif choice in ["8", "08"]:
                    run_url_comprehensive()
                else:
                    status_msg("!", "Invalid choice! Please select an option between 1 and 8.", RED)
                    time.sleep(1.2)

            # Page 2: Gift Card Generator
            elif current_page == 2:
                if choice in [str(i) for i in range(1, 9)] or choice in [f"0{i}" for i in range(1, 9)]:
                    run_giftcard_generator(choice.lstrip("0"))
                else:
                    status_msg("!", "Invalid choice! Please select a platform between 1 and 8.", RED)
                    time.sleep(1.2)

            # Page 3: Discord Developer & Utility Suite (Discord Checker)
            elif current_page == 3:
                if choice in [str(i) for i in range(1, 9)] or choice in [f"0{i}" for i in range(1, 9)]:
                    run_discord_suite(choice.lstrip("0"))
                else:
                    status_msg("!", "Invalid choice! Please select a module between 1 and 8.", RED)
                    time.sleep(1.2)

        except KeyboardInterrupt:
            clear_screen()
            print(f"\n\n{BOLD}{NEON_PURPLE}Process interrupted by user. Exiting...{RESET}\n")
            sys.exit(0)
        except Exception as e:
            status_msg("Error", f"An unexpected error occurred: {e}", RED)
            input(f"\n{GRAY}Press Enter to continue...{RESET}")

if __name__ == "__main__":
    main()
