"""
Banner & UI Layout for ASPECT Tool
Features the exact 'ansi_shadow' font from the reference image in vibrant neon purple.
"""

import os
import sys
from utils.colors import (
    NEON_PURPLE, DEEP_PURPLE, DARK_PURPLE, NEON_PINK,
    CYAN, GREEN, WHITE, GRAY, BOLD, RESET
)

BANNER_ART = r"""
 █████╗ ███████╗██████╗ ███████╗ ██████╗████████╗
██╔══██╗██╔════╝██╔══██╗██╔════╝██╔════╝╚══██╔══╝
███████║███████╗██████╔╝█████╗  ██║        ██║   
██╔══██║╚════██║██╔═══╝ ██╔══╝  ██║        ██║   
██║  ██║███████║██║     ███████╗╚██████╗   ██║   
╚═╝  ╚═╝╚══════╝╚═╝     ╚══════╝ ╚═════╝   ╚═╝   
"""

def clear_screen():
    """Clear terminal screen cross-platform."""
    os.system('clear' if os.name != 'nt' else 'cls')

def print_banner(page: int = 1):
    """Print the ASPECT neon purple banner, subtitle, and top-right page purpose badge."""
    clear_screen()
    print(f"{BOLD}{NEON_PURPLE}{BANNER_ART}{RESET}")

    badges = {
        1: "[ OSINT ]",
        2: "[ GENERATOR ]",
        3: "[ DISCORD CHECKER ]"
    }
    badge_str = badges.get(page, "[ MAIN ]")
    
    subtitle = "STRENGTH IS BORN FROM CHAOS"
    line_content = f"  {BOLD}{NEON_PINK}{subtitle}{RESET}"
    badge_styled = f"{BOLD}{CYAN}{badge_str}{RESET}"
    
    raw_sub_len = 29
    raw_badge_len = len(badge_str)
    spaces_needed = max(1, 61 - raw_sub_len - raw_badge_len - 2)

    sub_box = (
        f"{DARK_PURPLE}╭─────────────────────────────────────────────────────────────╮\n"
        f"│{line_content}{' ' * spaces_needed}{badge_styled}  {DARK_PURPLE}│\n"
        f"╰─────────────────────────────────────────────────────────────╯{RESET}"
    )
    print(sub_box)
    print()

def print_menu(page: int = 1):
    """Print the menu options in the 2-column cyberpunk neon style with pagination."""
    if page == 1:
        menu_lines = [
            f"{BOLD}{NEON_PURPLE}<<1>>{RESET} {WHITE}[Username Search]{RESET}            {BOLD}{NEON_PURPLE}<<5>>{RESET} {WHITE}[Phone Number OSINT]{RESET}",
            f"{BOLD}{NEON_PURPLE}<<2>>{RESET} {WHITE}[Email OSINT]{RESET}                 {BOLD}{NEON_PURPLE}<<6>>{RESET} {WHITE}[GitHub OSINT]{RESET}",
            f"{BOLD}{NEON_PURPLE}<<3>>{RESET} {WHITE}[Domain OSINT]{RESET}                {BOLD}{NEON_PURPLE}<<7>>{RESET} {WHITE}[Website Analysis]{RESET}",
            f"{BOLD}{NEON_PURPLE}<<4>>{RESET} {WHITE}[IP OSINT]{RESET}                    {BOLD}{NEON_PURPLE}<<8>>{RESET} {WHITE}[Comprehensive URL OSINT]{RESET}",
        ]
    elif page == 2:
        menu_lines = [
            f"{BOLD}{NEON_PURPLE}<<1>>{RESET} {WHITE}[Play Store]{RESET}                  {BOLD}{NEON_PURPLE}<<5>>{RESET} {WHITE}[Steam Gift]{RESET}",
            f"{BOLD}{NEON_PURPLE}<<2>>{RESET} {WHITE}[App Store]{RESET}                   {BOLD}{NEON_PURPLE}<<6>>{RESET} {WHITE}[Spotify Gift]{RESET}",
            f"{BOLD}{NEON_PURPLE}<<3>>{RESET} {WHITE}[Amazon Gift]{RESET}                 {BOLD}{NEON_PURPLE}<<7>>{RESET} {WHITE}[Discord Nitro]{RESET}",
            f"{BOLD}{NEON_PURPLE}<<4>>{RESET} {WHITE}[Netflix Gift]{RESET}                {BOLD}{NEON_PURPLE}<<8>>{RESET} {WHITE}[Xbox Gift]{RESET}",
        ]
    else:
        menu_lines = [
            f"{BOLD}{NEON_PURPLE}<<1>>{RESET} {WHITE}[Invite Link Analyzer]{RESET}         {BOLD}{NEON_PURPLE}<<5>>{RESET} {WHITE}[Markdown & Timestamp]{RESET}",
            f"{BOLD}{NEON_PURPLE}<<2>>{RESET} {WHITE}[Webhook Test & Sender]{RESET}        {BOLD}{NEON_PURPLE}<<6>>{RESET} {WHITE}[Server Widget & Assets]{RESET}",
            f"{BOLD}{NEON_PURPLE}<<3>>{RESET} {WHITE}[Snowflake ID Decrypter]{RESET}       {BOLD}{NEON_PURPLE}<<7>>{RESET} {WHITE}[API Latency & Ping]{RESET}",
            f"{BOLD}{NEON_PURPLE}<<4>>{RESET} {WHITE}[Bot & App Inspector]{RESET}          {BOLD}{NEON_PURPLE}<<8>>{RESET} {WHITE}[ID Cleaner & Sorter]{RESET}",
        ]

    # Add 2 empty lines between menu and bottom controls
    menu_lines.append("")
    menu_lines.append("")
    menu_lines.append(
        f"        {BOLD}{NEON_PURPLE}<<n>>{RESET} {CYAN}[Next]{RESET}        {BOLD}{NEON_PURPLE}<<b>>{RESET} {CYAN}[Back]{RESET}        {BOLD}{DEEP_PURPLE}<<0>>{RESET} {GRAY}[Exit]{RESET}"
    )

    for line in menu_lines:
        print(line)
    print()
