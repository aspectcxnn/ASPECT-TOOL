"""
Neon Purple / Cyberpunk ANSI Color Utilities for ASPECT Tool
"""

# Truecolor / 256-color ANSI codes
RESET = "\033[0m"
BOLD = "\033[1m"
DIM = "\033[2m"
ITALIC = "\033[3m"
UNDERLINE = "\033[4m"

# Neon Palette
NEON_PURPLE = "\033[38;2;192;132;252m"     # #c084fc (bright neon violet)
DEEP_PURPLE = "\033[38;2;147;51;234m"     # #9333ea (deep purple)
DARK_PURPLE = "\033[38;2;107;33;168m"     # #6b21a8 (shadow purple)
NEON_PINK = "\033[38;2;244;114;182m"       # #f472b6 (neon pink)
HOT_PINK = "\033[38;2;236;72;153m"         # #ec4899
CYAN = "\033[38;2;56;189;248m"             # #38bdf8 (cyber cyan)
GREEN = "\033[38;2;74;222;128m"           # #4ade80 (neon green)
YELLOW = "\033[38;2;250;204;21m"          # #facc15 (neon yellow)
RED = "\033[38;2;248;113;113m"            # #f87171 (soft red)
WHITE = "\033[38;2;248;250;252m"          # crisp white
GRAY = "\033[38;2;148;163;184m"           # slate gray
DARK_GRAY = "\033[38;2;71;85;105m"        # dark slate

def c(text: str, color: str = NEON_PURPLE, bold: bool = False) -> str:
    """Format text with specified ANSI color."""
    prefix = BOLD + color if bold else color
    return f"{prefix}{text}{RESET}"

def status_msg(tag: str, msg: str, tag_color: str = NEON_PURPLE, msg_color: str = WHITE) -> None:
    """Print a styled status message with tags like [>] or [+] or [-]."""
    print(f"{BOLD}{tag_color}[{tag}]{RESET} {msg_color}{msg}{RESET}")

def section_header(title: str) -> None:
    """Print a styled section header in neon purple."""
    line = "━" * 56
    print(f"\n{DEEP_PURPLE}{line}{RESET}")
    print(f"{BOLD}{NEON_PURPLE}  ◈ {title.upper()} ◈{RESET}")
    print(f"{DEEP_PURPLE}{line}{RESET}")

def key_val(key: str, val: str, indent: int = 2) -> None:
    """Print aligned key-value pair."""
    pad = " " * indent
    print(f"{pad}{NEON_PINK}{key:<24}:{RESET} {WHITE}{val}{RESET}")
